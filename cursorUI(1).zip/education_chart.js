// 学历分布数据
const educationData = [
  { value: 30, name: '硕士研究生', percent: '1.83%' },
  { value: 448, name: '本科', percent: '27.38%' },
  { value: 258, name: '大专', percent: '15.77%' },
  { value: 879, name: '中专及以下', percent: '53.73%' },
  { value: 21, name: '无学历', percent: '1.28%' }
];

// 设置饼图选项
option = {
  title: {
    text: '人员学历分布',
    left: 'center',
    textStyle: {
      fontSize: 32,
      fontWeight: 'bold'
    },
    top: 40
  },
  tooltip: {
    trigger: 'item',
    formatter: function(params) {
      return params.data.name + '<br/>' + 
             '人数: ' + params.data.value + '人<br/>' +
             '占比: ' + params.data.percent;
    },
    textStyle: {
      fontSize: 22
    },
    padding: 12
  },
  legend: {
    orient: 'vertical',
    left: 'left',
    padding: [30, 0, 0, 20],
    textStyle: {
      fontSize: 22
    },
    itemWidth: 36,
    itemHeight: 20,
    itemGap: 20
  },
  series: [
    {
      name: '学历分布',
      type: 'pie',
      radius: '55%',
      center: ['55%', '55%'],
      data: educationData,
      emphasis: {
        itemStyle: {
          shadowBlur: 10,
          shadowOffsetX: 0,
          shadowColor: 'rgba(0, 0, 0, 0.5)'
        }
      },
      label: {
        formatter: '{b}: {c}人 ({d}%)',
        fontSize: 22,
        fontWeight: 'bold'
      },
      labelLine: {
        length: 15,
        length2: 20,
        lineStyle: {
          width: 2
        }
      },
      itemStyle: {
        borderWidth: 2,
        borderColor: '#fff'
      }
    }
  ],
  color: ['#91cc75', '#5470c6', '#fac858', '#ee6666', '#73c0de']
}; 