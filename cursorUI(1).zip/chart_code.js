// 根据提供的数据创建原始数据数组 - 转置数据结构
const rawData = [
    [35, 0, 6, 140],     // 35岁及以下
    [172, 6, 77, 202],   // 36-45岁
    [240, 201, 58, 68],  // 46-54岁
    [159, 233, 13, 26]   // 55岁及以上
  ];
  
  // 计算每一列（用工类型）的总和
  const totalData = [];
  for (let i = 0; i < rawData[0].length; ++i) {
    let sum = 0;
    for (let j = 0; j < rawData.length; ++j) {
      sum += rawData[j][i];
    }
    totalData.push(sum);
  }
  
  // 设置图表网格
  const grid = {
    left: 240,
    right: 140,
    top: 120,
    bottom: 120
  };
  
  // 创建系列数据
  const series = [
    '35岁及以下',
    '36-45岁',
    '46-54岁',
    '55岁及以上'
  ].map((name, sid) => {
    return {
      name,
      type: 'bar',
      stack: 'total',
      barWidth: '65%',
      label: {
        show: true,
        formatter: function(params) {
          // 当值为0时不显示标签
          if (params.value === 0 || Math.round(params.value * 10) / 10 === 0) {
            return '';
          }
          return Math.round(params.value * 10) / 10 + '%';
        },
        fontSize: 24,
        fontWeight: 'bold',
        distance: 5
      },
      data: rawData[sid].map((d, did) =>
        totalData[did] <= 0 ? 0 : (d / totalData[did]) * 100
      )
    };
  });
  
  // 设置图表选项
  option = {
    title: {
      text: '各用工类型年龄段分布',
      left: 'center',
      textStyle: {
        fontSize: 32,
        fontWeight: 'bold'
      },
      top: 40
    },
    tooltip: {
      trigger: 'axis',
      axisPointer: {
        type: 'shadow'
      },
      formatter: function(params) {
        let tar = params[0].name + '<br/>';
        let sum = 0;
        for (let i = 0; i < params.length; i++) {
          sum += rawData[params[i].seriesIndex][params[i].dataIndex];
          tar += params[i].seriesName + ': ' + 
                 rawData[params[i].seriesIndex][params[i].dataIndex] + '人 (' + 
                 params[i].value.toFixed(1) + '%)<br/>';
        }
        tar += '<div style="border-top: 1px solid rgba(0,0,0,.1); margin: 5px 0;"></div>';
        tar += '总人数: ' + sum + '人';
        return tar;
      },
      textStyle: {
        fontSize: 22
      },
      padding: 12
    },
    legend: {
      data: ['35岁及以下', '36-45岁', '46-54岁', '55岁及以上'],
      bottom: '2%',
      textStyle: {
        fontSize: 22
      },
      itemWidth: 36,
      itemHeight: 20,
      padding: [10, 15, 20, 15],
      itemGap: 20
    },
    grid,
    xAxis: {
      type: 'value',
      axisLabel: {
        formatter: '{value}%',
        fontSize: 22,
        margin: 16
      },
      max: 100,
      axisPointer: {
        label: {
          formatter: function(params) {
            return params.value.toFixed(1) + '%';
          },
          fontSize: 22
        }
      },
      nameTextStyle: {
        fontSize: 22
      },
      axisLine: {
        lineStyle: {
          width: 3
        }
      },
      splitLine: {
        lineStyle: {
          width: 2
        }
      },
      axisTick: {
        length: 8,
        lineStyle: {
          width: 2
        }
      }
    },
    yAxis: {
      type: 'category',
      data: [
        '全民用工 (平均年龄: 48.62岁)', 
        '集体用工 (平均年龄: 54.32岁)', 
        '合同制用工 (平均年龄: 44.76岁)', 
        '劳务派遣用工 (平均年龄: 39.48岁)'
      ],
      axisLabel: {
        interval: 0,
        formatter: function(value) {
          // 处理长文本换行
          return value.replace(' (平均年龄: ', '\n(平均年龄: ');
        },
        fontSize: 22,
        margin: 30,
        padding: [5, 0, 5, 0]
      },
      nameTextStyle: {
        fontSize: 22
      },
      axisLine: {
        lineStyle: {
          width: 3
        }
      },
      axisTick: {
        length: 8,
        lineStyle: {
          width: 2
        }
      }
    },
    series
  }; 