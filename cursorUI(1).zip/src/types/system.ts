// 角色相关类型定义
export interface Role {
  id: string
  name: string
  code: string
  description: string
  status: boolean
  createTime: string
}

// 权限树节点类型
export interface PermissionTreeNode {
  title: string
  key: string
  children?: PermissionTreeNode[]
}

// 表单状态类型
export interface RoleFormState {
  name: string
  code: string
  description: string
}

// 字段定义类型
export interface FieldDefinition {
  name: string
  label: string
  fieldType: 'text' | 'number' | 'select' | 'date' | 'textarea' | 'cascader' | 'upload'
  required: boolean
  options?: string[]
  validation?: string[]
  sort: number
  description?: string
}

// 记录结构类型
export interface RecordStructure {
  type: 'land' | 'property'
  fields: FieldDefinition[]
} 