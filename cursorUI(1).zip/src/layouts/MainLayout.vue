<template>
  <a-layout class="layout-container">
    <a-layout-header class="header">
      <div class="header-left">
        <div class="logo">
          <HomeOutlined class="logo-icon" />
          土地资源与房产管理系统
        </div>
      </div>
      <div class="header-right">
        <a-space>
          <a-badge :count="5">
            <BellOutlined class="header-icon" />
          </a-badge>
          <a-dropdown>
            <div class="user-info">
              <UserOutlined class="avatar-icon" />
              <span class="username">{{ userInfo.name }}</span>
              <DownOutlined />
            </div>
            <template #overlay>
              <a-menu>
                <a-menu-item key="profile">
                  <UserOutlined />
                  <span>个人信息</span>
                </a-menu-item>
                <a-menu-item key="settings">
                  <SettingOutlined />
                  <span>账号设置</span>
                </a-menu-item>
                <a-menu-divider />
                <a-menu-item key="logout" @click="handleLogout">
                  <LogoutOutlined />
                  <span>退出登录</span>
                </a-menu-item>
              </a-menu>
            </template>
          </a-dropdown>
        </a-space>
      </div>
    </a-layout-header>
    
    <a-layout class="main-layout">
      <a-layout-sider width="240" class="sider">
        <a-menu
          mode="inline"
          v-model:selectedKeys="selectedKeys"
          v-model:openKeys="openKeys"
          :style="{ height: '100%' }"
          @select="handleMenuSelect"
        >
          <template v-for="item in menuItems" :key="item.key">
            <template v-if="item.children">
              <a-sub-menu :key="item.key">
                <template #title>
                  <component :is="item.icon" />
                  <span>{{ item.label }}</span>
                </template>
                <a-menu-item v-for="child in item.children" :key="child.key">
                  <component :is="child.icon" />
                  <span>{{ child.label }}</span>
                </a-menu-item>
              </a-sub-menu>
            </template>
            <template v-else>
              <a-menu-item :key="item.key">
                <component :is="item.icon" />
                <span>{{ item.label }}</span>
              </a-menu-item>
            </template>
          </template>
        </a-menu>
      </a-layout-sider>
      
      <a-layout-content class="content">
        <div class="content-wrapper">
          <router-view></router-view>
        </div>
      </a-layout-content>
    </a-layout>
  </a-layout>
</template>

<script lang="ts" setup>
import { ref, onMounted } from 'vue'
import { useRouter, useRoute } from 'vue-router'
import {
  DashboardOutlined,
  HomeOutlined,
  TeamOutlined,
  ToolOutlined,
  UserOutlined,
  BarChartOutlined,
  SafetyCertificateOutlined,
  SettingOutlined,
  BorderOuterOutlined,
  TableOutlined,
  BellOutlined,
  DownOutlined,
  LogoutOutlined
} from '@ant-design/icons-vue'

const router = useRouter()
const route = useRoute()

const selectedKeys = ref<string[]>(['dashboard'])
const openKeys = ref<string[]>(['system'])

// 用户信息
const userInfo = ref({
  name: '管理员',
  avatar: '',
  roles: ['admin']
})

// 处理退出登录
const handleLogout = () => {
  // TODO: 实现退出登录逻辑
  router.push('/login')
}

// 菜单配置
const menuItems = [
  {
    key: 'dashboard',
    label: '仪表盘',
    icon: DashboardOutlined
  },
  {
    key: 'system',
    label: '组织架构',
    icon: SettingOutlined,
    children: [
      {
        key: 'users',
        label: '用户管理',
        icon: UserOutlined
      },
      {
        key: 'departments',
        label: '部门管理',
        icon: TeamOutlined
      },
      {
        key: 'roles',
        label: '角色管理',
        icon: TeamOutlined
      },
      {
        key: 'permissions',
        label: '权限管理',
        icon: SafetyCertificateOutlined
      },
      {
        key: 'record-structure',
        label: '记录结构',
        icon: TableOutlined
      }
    ]
  },
  {
    key: 'assets',
    label: '资产管理',
    icon: BorderOuterOutlined,
    children: [
      {
        key: 'land',
        label: '土地资源',
        icon: BorderOuterOutlined
      },
      {
        key: 'properties',
        label: '房产管理',
        icon: HomeOutlined
      },
      {
        key: 'asset-import',
        label: '导入',
        icon: ToolOutlined
      },
    ]
  },
  {
    key: 'reports',
    label: '报表统计',
    icon: BarChartOutlined
  }
]

// 菜单选择处理
const handleMenuSelect = ({ key }: { key: string }) => {
  router.push({ name: key })
}

// 根据当前路由设置选中菜单
onMounted(() => {
  const currentRoute = route.name as string
  if (currentRoute) {
    selectedKeys.value = [currentRoute]
    if (['users', 'roles', 'permissions'].includes(currentRoute)) {
      openKeys.value = ['system']
    }
  }
})
</script>

<style lang="scss" scoped>
@import '@/styles/variables.scss';

.layout-container {
  min-height: 100vh;
  background: $background-light;
}

.header {
  background: linear-gradient(135deg, $primary-color, $secondary-color);
  padding: 0 $spacing-lg;
  box-shadow: $shadow-sm;
  display: flex;
  justify-content: space-between;
  align-items: center;
  height: 64px;
}

.header-left {
  display: flex;
  align-items: center;
}

.header-right {
  display: flex;
  align-items: center;
  
  .header-icon {
    font-size: 20px;
    color: white;
    cursor: pointer;
    padding: 4px;
    
    &:hover {
      background: rgba(255, 255, 255, 0.1);
      border-radius: $border-radius-sm;
    }
  }
}

.user-info {
  display: flex;
  align-items: center;
  color: white;
  cursor: pointer;
  padding: 4px 8px;
  border-radius: $border-radius-sm;
  
  &:hover {
    background: rgba(255, 255, 255, 0.1);
  }
  
  .avatar-icon {
    font-size: 20px;
    margin-right: $spacing-sm;
  }
  
  .username {
    margin-right: $spacing-xs;
  }
}

.logo {
  color: white;
  font-size: 20px;
  display: flex;
  align-items: center;
  gap: $spacing-sm;
  
  .logo-icon {
    font-size: 24px;
  }
}

.main-layout {
  margin: $spacing-lg;
  background: transparent;
}

.sider {
  background: white;
  border-radius: $border-radius-lg;
  padding: $spacing-md;
  box-shadow: $shadow-md;
  margin-right: $spacing-lg;
}

.custom-menu {
  :deep(.ant-menu-sub) {
    background: transparent;
  }

  :deep(.ant-menu-submenu-title) {
    border-radius: $border-radius-md;
    margin: $spacing-xs 0;
    
    &:hover {
      background: rgba($primary-color, 0.1);
    }
  }

  :deep(.ant-menu-submenu-selected > .ant-menu-submenu-title) {
    color: $primary-color;
  }
}

.content {
  background: transparent;
  
  .content-wrapper {
    background: white;
    border-radius: $border-radius-lg;
    padding: $spacing-lg;
    min-height: calc(100vh - 96px);
    box-shadow: $shadow-md;
  }
}
</style> 