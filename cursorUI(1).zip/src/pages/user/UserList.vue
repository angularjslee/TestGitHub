<template>
  <div class="user-list">
    <div class="page-header">
      <h2>用户管理</h2>
      <div class="header-actions">
        <a-space>
          <a-button type="primary" @click="showCreateModal" class="custom-button">
            <template #icon><PlusOutlined /></template>
            新建用户
          </a-button>
          <a-input-search
            v-model:value="searchText"
            placeholder="搜索用户名/姓名/手机号"
            class="custom-search"
            @search="onSearch"
          />
        </a-space>
      </div>
    </div>

    <a-card class="custom-card">
      <a-table
        :columns="columns"
        :data-source="userList"
        :loading="loading"
        :pagination="pagination"
        @change="handleTableChange"
        class="custom-table"
      >
        <!-- 用户状态列 -->
        <template #status="{ text }">
          <a-tag :class="['status-tag', text === '启用' ? 'status-active' : 'status-inactive']">
            {{ text }}
          </a-tag>
        </template>

        <!-- 操作列 -->
        <template #action="{ record }">
          <a-space>
            <a class="action-link" @click="showEditModal(record)">编辑</a>
            <a-divider type="vertical" />
            <a class="action-link" @click="showRoleModal(record)">角色</a>
            <a-divider type="vertical" />
            <a-popconfirm
              :title="record.status === '启用' ? '确定要禁用该用户吗？' : '确定要启用该用户吗？'"
              @confirm="toggleUserStatus(record)"
            >
              <a class="action-link">{{ record.status === '启用' ? '禁用' : '启用' }}</a>
            </a-popconfirm>
          </a-space>
        </template>
      </a-table>
    </a-card>

    <!-- 创建/编辑用户弹窗 -->
    <a-modal
      v-model:visible="modalVisible"
      :title="modalTitle"
      @ok="handleModalOk"
      @cancel="handleModalCancel"
      class="custom-modal"
    >
      <a-form
        ref="formRef"
        :model="formState"
        :rules="rules"
        :label-col="{ span: 6 }"
        :wrapper-col="{ span: 16 }"
        class="custom-form"
      >
        <a-form-item label="用户名" name="username">
          <a-input v-model:value="formState.username" :disabled="isEdit" />
        </a-form-item>
        <a-form-item label="姓名" name="realName">
          <a-input v-model:value="formState.realName" />
        </a-form-item>
        <a-form-item label="手机号" name="phone">
          <a-input v-model:value="formState.phone" />
        </a-form-item>
        <a-form-item label="邮箱" name="email">
          <a-input v-model:value="formState.email" />
        </a-form-item>
        <a-form-item v-if="!isEdit" label="密码" name="password">
          <a-input-password v-model:value="formState.password" />
        </a-form-item>
      </a-form>
    </a-modal>

    <!-- 分配角色弹窗 -->
    <a-modal
      v-model:visible="roleModalVisible"
      title="分配角色"
      @ok="handleRoleModalOk"
      @cancel="handleRoleModalCancel"
      class="custom-modal"
    >
      <a-transfer
        v-model:target-keys="selectedRoles"
        :data-source="roleList"
        :titles="['可选角色', '已选角色']"
        :render="renderItem"
        class="custom-transfer"
      />
    </a-modal>
  </div>
</template>

<script lang="ts" setup>
import { ref, reactive } from 'vue'
import { PlusOutlined } from '@ant-design/icons-vue'
import type { TableColumnsType } from 'ant-design-vue'
import { message } from 'ant-design-vue'

// 表格列定义
const columns: TableColumnsType = [
  {
    title: '用户名',
    dataIndex: 'username',
    key: 'username',
  },
  {
    title: '姓名',
    dataIndex: 'realName',
    key: 'realName',
  },
  {
    title: '手机号',
    dataIndex: 'phone',
    key: 'phone',
  },
  {
    title: '邮箱',
    dataIndex: 'email',
    key: 'email',
  },
  {
    title: '状态',
    dataIndex: 'status',
    key: 'status',
    slots: { customRender: 'status' }
  },
  {
    title: '创建时间',
    dataIndex: 'createTime',
    key: 'createTime',
  },
  {
    title: '操作',
    key: 'action',
    slots: { customRender: 'action' }
  }
]

// 表格数据
const loading = ref(false)
const userList = ref([])
const pagination = reactive({
  current: 1,
  pageSize: 10,
  total: 0
})

// 搜索
const searchText = ref('')
const onSearch = (value: string) => {
  console.log('搜索关键词:', value)
  pagination.current = 1
  fetchUserList()
}

// 表格变化处理
const handleTableChange = (pag: any) => {
  pagination.current = pag.current
  pagination.pageSize = pag.pageSize
  fetchUserList()
}

// 获取用户列表
const fetchUserList = async () => {
  loading.value = true
  try {
    // TODO: 调用后端API获取用户列表
    // const res = await getUserList({
    //   page: pagination.current,
    //   pageSize: pagination.pageSize,
    //   keyword: searchText.value
    // })
    // userList.value = res.data.list
    // pagination.total = res.data.total
  } catch (error) {
    message.error('获取用户列表失败')
  }
  loading.value = false
}

// 表单相关
const formRef = ref()
const modalVisible = ref(false)
const modalTitle = ref('新建用户')
const isEdit = ref(false)

const formState = reactive({
  username: '',
  realName: '',
  phone: '',
  email: '',
  password: ''
})

const rules = {
  username: [
    { required: true, message: '请输入用户名' },
    { min: 4, message: '用户名至少4个字符' }
  ],
  realName: [{ required: true, message: '请输入姓名' }],
  phone: [
    { required: true, message: '请输入手机号' },
    { pattern: /^1[3-9]\d{9}$/, message: '请输入正确的手机号' }
  ],
  email: [
    { required: true, message: '请输入邮箱' },
    { type: 'email', message: '请输入正确的邮箱格式' }
  ],
  password: [
    { required: true, message: '请输入密码' },
    { min: 6, message: '密码至少6个字符' }
  ]
}

// 显示创建用户弹窗
const showCreateModal = () => {
  modalTitle.value = '新建用户'
  isEdit.value = false
  Object.assign(formState, {
    username: '',
    realName: '',
    phone: '',
    email: '',
    password: ''
  })
  modalVisible.value = true
}

// 显示编辑用户弹窗
const showEditModal = (record: any) => {
  modalTitle.value = '编辑用户'
  isEdit.value = true
  Object.assign(formState, {
    username: record.username,
    realName: record.realName,
    phone: record.phone,
    email: record.email
  })
  modalVisible.value = true
}

// 弹窗确认
const handleModalOk = () => {
  formRef.value.validate().then(() => {
    // TODO: 调用后端API保存用户信息
    message.success(isEdit.value ? '编辑成功' : '创建成功')
    modalVisible.value = false
    fetchUserList()
  })
}

// 弹窗取消
const handleModalCancel = () => {
  modalVisible.value = false
  formRef.value.resetFields()
}

// 角色相关
const roleModalVisible = ref(false)
const selectedRoles = ref<string[]>([])
const roleList = ref([
  { key: '1', title: '管理员' },
  { key: '2', title: '普通用户' },
  { key: '3', title: '访客' }
])

// 修改 Transfer 的 render 函数
const renderItem = (item: { title: string }) => item.title

// 修改显示角色弹窗函数
const showRoleModal = (record: any) => {
  console.log('当前用户:', record.username)
  // TODO: 获取用户当前角色
  selectedRoles.value = record.roles || ['1']
  roleModalVisible.value = true
}

// 角色弹窗确认
const handleRoleModalOk = () => {
  // TODO: 调用后端API保存用户角色
  message.success('角色分配成功')
  roleModalVisible.value = false
}

// 角色弹窗取消
const handleRoleModalCancel = () => {
  roleModalVisible.value = false
}

// 切换用户状态
const toggleUserStatus = async (record: any) => {
  try {
    // TODO: 调用后端API修改用户状态
    message.success(record.status === '启用' ? '已禁用' : '已启用')
    fetchUserList()
  } catch (error) {
    message.error('操作失败')
  }
}

// 初始化
fetchUserList()
</script>

<style lang="scss" scoped>
.user-list {
  .page-header {
    margin-bottom: $spacing-lg;
    
    h2 {
      color: $text-primary;
      margin-bottom: $spacing-md;
      font-size: 24px;
    }
  }

  .header-actions {
    display: flex;
    justify-content: space-between;
    align-items: center;
  }

  .custom-button {
    background: $primary-color;
    border-color: $primary-color;
    border-radius: $border-radius-md;
    
    &:hover {
      background: darken($primary-color, 5%);
      border-color: darken($primary-color, 5%);
    }
  }

  .custom-search {
    width: 300px;
    
    :deep(.ant-input) {
      border-radius: $border-radius-md;
    }
    
    :deep(.ant-input-search-button) {
      border-radius: 0 $border-radius-md $border-radius-md 0;
    }
  }

  .custom-card {
    border-radius: $border-radius-lg;
    box-shadow: $shadow-sm;
  }

  .custom-table {
    :deep(.ant-table-thead > tr > th) {
      background: $background-light;
      color: $text-primary;
    }
    
    :deep(.ant-table-tbody > tr > td) {
      color: $text-secondary;
    }
  }

  .status-tag {
    border-radius: $border-radius-sm;
    padding: 4px 12px;
    
    &.status-active {
      background: rgba($success-color, 0.1);
      color: darken($success-color, 20%);
      border-color: $success-color;
    }
    
    &.status-inactive {
      background: rgba($error-color, 0.1);
      color: darken($error-color, 20%);
      border-color: $error-color;
    }
  }

  .action-link {
    color: $primary-color;
    
    &:hover {
      color: darken($primary-color, 10%);
    }
  }

  .custom-modal {
    :deep(.ant-modal-content) {
      border-radius: $border-radius-lg;
    }
    
    :deep(.ant-modal-header) {
      border-radius: $border-radius-lg $border-radius-lg 0 0;
    }
  }

  .custom-form {
    :deep(.ant-form-item-label > label) {
      color: $text-primary;
    }
    
    :deep(.ant-input) {
      border-radius: $border-radius-md;
      
      &:focus {
        border-color: $primary-color;
        box-shadow: 0 0 0 2px rgba($primary-color, 0.2);
      }
    }
  }

  .custom-transfer {
    :deep(.ant-transfer-list) {
      border-radius: $border-radius-md;
    }
    
    :deep(.ant-transfer-list-header) {
      background: $background-light;
    }
    
    :deep(.ant-transfer-list-content-item) {
      &:hover {
        background: rgba($primary-color, 0.1);
      }
    }
    
    :deep(.ant-transfer-list-content-item-checked) {
      background: rgba($primary-color, 0.2);
    }
  }
}
</style> 