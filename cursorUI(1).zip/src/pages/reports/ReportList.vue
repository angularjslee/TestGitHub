<template>
  <div class="report-list">
    <div class="page-header">
      <h2>报表统计</h2>
      <div class="header-actions">
        <a-space>
          <a-range-picker
            v-model:value="dateRange"
            style="width: 250px"
            placeholder="['开始日期', '结束日期']"
          />
          <a-button type="primary">
            <template #icon><LineChartOutlined /></template>
            生成报表
          </a-button>
          <a-button>
            <template #icon><DownloadOutlined /></template>
            导出报表
          </a-button>
        </a-space>
      </div>
    </div>

    <!-- 数据概览卡片 -->
    <a-row :gutter="16" class="stat-cards">
      <a-col :span="6">
        <a-card>
          <a-statistic
            title="总房产数量"
            :value="156"
            :value-style="{ color: '#3f8600' }"
          >
            <template #prefix>
              <HomeOutlined />
            </template>
          </a-statistic>
        </a-card>
      </a-col>
      <a-col :span="6">
        <a-card>
          <a-statistic
            title="使用率"
            :value="84.2"
            :precision="1"
            suffix="%"
            :value-style="{ color: '#3f8600' }"
          >
            <template #prefix>
              <PieChartOutlined />
            </template>
          </a-statistic>
        </a-card>
      </a-col>
      <a-col :span="6">
        <a-card>
          <a-statistic
            title="维护成本"
            :value="125680"
            prefix="¥"
            :value-style="{ color: '#cf1322' }"
          >
            <template #prefix>
              <AccountBookOutlined />
            </template>
          </a-statistic>
        </a-card>
      </a-col>
      <a-col :span="6">
        <a-card>
          <a-statistic
            title="闲置率"
            :value="15.8"
            :precision="1"
            suffix="%"
            :value-style="{ color: '#faad14' }"
          >
            <template #prefix>
              <WarningOutlined />
            </template>
          </a-statistic>
        </a-card>
      </a-col>
    </a-row>

    <!-- 表格数据 -->
    <a-card title="详细数据" class="data-table">
      <a-table :columns="columns" :data-source="data" :loading="loading">
        <template #bodyCell="{ column, record }">
          <template v-if="column.key === 'trend'">
            <span :class="record.trend > 0 ? 'trend-up' : 'trend-down'">
              {{ record.trend }}%
              <CaretUpOutlined v-if="record.trend > 0" />
              <CaretDownOutlined v-if="record.trend < 0" />
            </span>
          </template>
        </template>
      </a-table>
    </a-card>
  </div>
</template>

<script lang="ts" setup>
import { ref } from 'vue'
import type { TableColumnsType } from 'ant-design-vue'
import {
  LineChartOutlined,
  DownloadOutlined,
  HomeOutlined,
  PieChartOutlined,
  AccountBookOutlined,
  WarningOutlined,
  CaretUpOutlined,
  CaretDownOutlined
} from '@ant-design/icons-vue'

const dateRange = ref()
const loading = ref(false)

const columns: TableColumnsType = [
  {
    title: '指标名称',
    dataIndex: 'name',
    key: 'name',
  },
  {
    title: '当前值',
    dataIndex: 'value',
    key: 'value',
  },
  {
    title: '环比变化',
    dataIndex: 'trend',
    key: 'trend',
  },
  {
    title: '说明',
    dataIndex: 'description',
    key: 'description',
  }
]

const data = [
  {
    key: '1',
    name: '房产总数',
    value: '156个',
    trend: 5.2,
    description: '包括所有类型的房产'
  },
  {
    key: '2',
    name: '平均使用率',
    value: '84.2%',
    trend: 2.1,
    description: '工作日平均使用率'
  },
  {
    key: '3',
    name: '维护成本',
    value: '¥125,680',
    trend: -3.5,
    description: '本月维护总支出'
  },
  {
    key: '4',
    name: '闲置率',
    value: '15.8%',
    trend: -1.2,
    description: '当前闲置房产比例'
  }
]
</script>

<style lang="scss" scoped>
.report-list {
  .page-header {
    margin-bottom: 24px;
    
    h2 {
      margin-bottom: 16px;
      font-size: 24px;
    }
  }

  .stat-cards {
    margin-bottom: 24px;
  }

  .data-table {
    .trend-up {
      color: #3f8600;
    }

    .trend-down {
      color: #cf1322;
    }
  }
}
</style> 