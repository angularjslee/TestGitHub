<template>
  <div class="property-list">
    <div class="page-header">
      <h2>房产管理</h2>
      <div class="header-actions">
        <a-space>
          <a-button type="primary" @click="showCreateModal" class="custom-button">
            <template #icon><PlusOutlined /></template>
            申报房产
          </a-button>
          <a-input-search
            v-model:value="searchText"
            placeholder="搜索地址/房间号/用途"
            style="width: 250px"
            @search="onSearch"
          />
          <a-button @click="showAdvancedSearch">
            <template #icon><FilterOutlined /></template>
            高级筛选
          </a-button>
        </a-space>
      </div>
    </div>

    <a-card class="custom-card">
      <a-table
        :columns="columns"
        :data-source="propertyList"
        :loading="loading"
        :pagination="pagination"
        @change="handleTableChange"
        class="custom-table"
      >
        <!-- 状态列 -->
        <template #status="{ text }">
          <a-tag :class="getStatusClass(text)">
            {{ text }}
          </a-tag>
        </template>

        <!-- 操作列 -->
        <template #action="{ record }">
          <a-space>
            <a class="action-link" @click="showDetailModal(record)">查看</a>
            <a-divider type="vertical" />
            <a class="action-link" @click="showEditModal(record)">编辑</a>
          </a-space>
        </template>
      </a-table>
    </a-card>

    <!-- 房产申报/编辑弹窗 -->
    <a-modal
      v-model:visible="modalVisible"
      :title="modalTitle"
      width="800px"
      @ok="handleModalOk"
      @cancel="handleModalCancel"
      class="custom-modal"
    >
      <a-form
        ref="formRef"
        :model="formState"
        :rules="rules"
        :label-col="{ span: 6 }"
        :wrapper-col="{ span: 16 }"
        class="custom-form"
      >
        <template v-for="group in groupedFields" :key="group.title">
          <a-divider>{{ group.title }}</a-divider>
          <template v-for="field in group.fields" :key="field.name">
            <a-form-item
              :label="field.label"
              :name="field.name"
              :required="field.required"
            >
              <!-- 文本输入 -->
              <a-input
                v-if="field.fieldType === 'text'"
                v-model:value="formState[field.name]"
                :placeholder="`请输入${field.label}`"
              />
              
              <!-- 数字输入 -->
              <a-input-number
                v-else-if="field.fieldType === 'number'"
                v-model:value="formState[field.name]"
                :precision="2"
                :min="0"
                style="width: 100%"
                :placeholder="`请输入${field.label}`"
              />
              
              <!-- 下拉选择 -->
              <a-select
                v-else-if="field.fieldType === 'select'"
                v-model:value="formState[field.name]"
                :placeholder="`请选择${field.label}`"
              >
                <a-select-option
                  v-for="option in field.options"
                  :key="option"
                  :value="option"
                >
                  {{ option }}
                </a-select-option>
              </a-select>
              
              <!-- 日期选择 -->
              <a-date-picker
                v-else-if="field.fieldType === 'date'"
                v-model:value="formState[field.name]"
                style="width: 100%"
                :placeholder="`请选择${field.label}`"
              />
              
              <!-- 多行文本 -->
              <a-textarea
                v-else-if="field.fieldType === 'textarea'"
                v-model:value="formState[field.name]"
                :rows="3"
                :placeholder="`请输入${field.label}`"
              />
            </a-form-item>
          </template>
        </template>
      </a-form>
    </a-modal>

    <!-- 高级搜索抽屉 -->
    <a-drawer
      v-model:visible="searchDrawerVisible"
      title="高级搜索"
      placement="right"
      width="400"
    >
      <a-form layout="vertical">
        <a-form-item label="使用状态">
          <a-select v-model:value="advancedSearch.status" mode="multiple">
            <a-select-option value="idle">闲置</a-select-option>
            <a-select-option value="inUse">使用中</a-select-option>
            <a-select-option value="maintenance">维护中</a-select-option>
          </a-select>
        </a-form-item>
        
        <a-form-item label="房间用途">
          <a-select v-model:value="advancedSearch.purpose" mode="multiple">
            <a-select-option value="office">办公</a-select-option>
            <a-select-option value="meeting">会议室</a-select-option>
            <a-select-option value="rest">休息区</a-select-option>
            <a-select-option value="storage">储物间</a-select-option>
          </a-select>
        </a-form-item>
        
        <a-form-item label="面积范围">
          <a-space>
            <a-input-number v-model:value="advancedSearch.minArea" placeholder="最小面积" />
            <span>-</span>
            <a-input-number v-model:value="advancedSearch.maxArea" placeholder="最大面积" />
          </a-space>
        </a-form-item>
        
        <a-form-item label="产权归属部门">
          <a-select
            v-model:value="advancedSearch.department"
            mode="multiple"
            placeholder="请选择部门"
          >
            <a-select-option v-for="dept in departments" :key="dept.id" :value="dept.id">
              {{ dept.name }}
            </a-select-option>
          </a-select>
        </a-form-item>
      </a-form>
      
      <div class="drawer-footer">
        <a-space>
          <a-button @click="resetAdvancedSearch">重置</a-button>
          <a-button type="primary" @click="handleAdvancedSearch">搜索</a-button>
        </a-space>
      </div>
    </a-drawer>
  </div>
</template>

<script lang="ts" setup>
import { ref, reactive, computed } from 'vue'
import { message } from 'ant-design-vue'
import type { TableColumnsType } from 'ant-design-vue'
import type { FieldDefinition } from '@/types/system'
import {
  PlusOutlined,
  FilterOutlined,
  UploadOutlined
} from '@ant-design/icons-vue'

// 表格列定义
const columns: TableColumnsType = [
  {
    title: '资产编码',
    dataIndex: 'assetCode',
    key: 'assetCode',
    width: 120
  },
  {
    title: '房产名称',
    dataIndex: 'propertyName',
    key: 'propertyName',
    width: 150
  },
  {
    title: '位置',
    key: 'location',
    width: 200,
    customRender: ({ record }: { record: any }) => 
      `${record.province}${record.city}${record.district}${record.address}`
  },
  {
    title: '建筑面积(㎡)',
    dataIndex: 'buildingArea',
    key: 'buildingArea',
    width: 120
  },
  {
    title: '已使用面积(㎡)',
    dataIndex: 'usedArea',
    key: 'usedArea',
    width: 120
  },
  {
    title: '闲置面积(㎡)',
    dataIndex: 'idleArea',
    key: 'idleArea',
    width: 120
  },
  {
    title: '状态',
    dataIndex: 'status',
    key: 'status',
    width: 100,
    slots: { customRender: 'status' }
  },
  {
    title: '操作',
    key: 'action',
    width: 200,
    fixed: 'right',
    slots: { customRender: 'action' }
  }
]

// 表格数据
const loading = ref(false)
const propertyList = ref([])
const pagination = reactive({
  current: 1,
  pageSize: 10,
  total: 0
})

// 搜索相关
const searchText = ref('')
const searchDrawerVisible = ref(false)
const advancedSearch = reactive({
  status: [],
  purpose: [],
  minArea: undefined,
  maxArea: undefined,
  department: []
})

// 表单相关
const formRef = ref()
const modalVisible = ref(false)
const modalTitle = ref('申报房产')
const formState = reactive({
  address: [],
  doorNumber: '',
  floor: undefined,
  roomNumber: '',
  area: undefined,
  purpose: undefined,
  department: undefined,
  propertyType: undefined,
  facilities: [],
  documents: []
})

// 模拟部门数据
const departments = [
  { id: '1', name: '技术部' },
  { id: '2', name: '人事部' },
  { id: '3', name: '财务部' }
]

// 模拟地址选项
const addressOptions = [
  {
    value: 'zhejiang',
    label: '浙江省',
    children: [
      {
        value: 'hangzhou',
        label: '杭州市',
        children: [
          {
            value: 'xihu',
            label: '西湖区'
          }
        ]
      }
    ]
  }
]

// 字段定义
const fields = ref<FieldDefinition[]>([])

// 按组分类的字段
const groupedFields = computed(() => {
  const groups = [
    { title: '基本信息', fields: [] },
    { title: '地址信息', fields: [] },
    { title: '房产信息', fields: [] },
    { title: '面积信息', fields: [] },
    { title: '权证信息', fields: [] },
    { title: '资产信息', fields: [] },
    { title: '其他信息', fields: [] }
  ]
  
  fields.value.forEach(field => {
    if (field.sort <= 5) {
      groups[0].fields.push(field)
    } else if (field.sort <= 10) {
      groups[1].fields.push(field)
    } else if (field.sort <= 15) {
      groups[2].fields.push(field)
    } else if (field.sort <= 22) {
      groups[3].fields.push(field)
    } else if (field.sort <= 25) {
      groups[4].fields.push(field)
    } else if (field.sort <= 28) {
      groups[5].fields.push(field)
    } else {
      groups[6].fields.push(field)
    }
  })
  
  return groups.filter(group => group.fields.length > 0)
})

// 获取房产列表
const fetchPropertyList = async () => {
  loading.value = true
  try {
    // TODO: 调用后端API获取房产列表
    await new Promise(resolve => setTimeout(resolve, 500))
    propertyList.value = [
      {
        id: '1',
        companyName: '示例企业',
        companyCode: 'CP001',
        landId: 'L001',
        assetCode: 'P001',
        propertyName: '研发中心大楼',
        province: '浙江省',
        city: '杭州市',
        district: '西湖区',
        address: '西湖区文三路100号',
        coordinates: '120.123456,30.123456',
        source: '自建',
        investmentSource: '自有资金',
        propertyType: '办公用房',
        buildYear: 2015,
        floors: 12,
        buildingArea: 5000,
        usableArea: 4500,
        usedArea: 4000,
        selfUsedArea: 3000,
        rentedArea: 1000,
        occupiedArea: 0,
        idleArea: 500,
        hasCertificate: '是',
        certificateHolder: '示例企业',
        certificateNumber: 'C123456',
        originalValue: 50000000,
        netValue: 45000000,
        usage: '办公',
        status: '使用中'
      },
      {
        id: '2',
        companyName: '示例企业',
        companyCode: 'CP001',
        landId: 'L002',
        assetCode: 'P002',
        propertyName: '员工宿舍楼',
        province: '浙江省',
        city: '杭州市',
        district: '滨江区',
        address: '滨江区江南大道200号',
        coordinates: '120.234567,30.234567',
        source: '购置',
        investmentSource: '银行贷款',
        propertyType: '住宅',
        buildYear: 2018,
        floors: 18,
        buildingArea: 8000,
        usableArea: 7200,
        usedArea: 6000,
        selfUsedArea: 6000,
        rentedArea: 0,
        occupiedArea: 0,
        idleArea: 1200,
        hasCertificate: '是',
        certificateHolder: '示例企业',
        certificateNumber: 'C234567',
        originalValue: 80000000,
        netValue: 75000000,
        usage: '员工住宿',
        status: '使用中'
      }
    ]
  } catch (error) {
    message.error('获取房产列表失败')
  }
  loading.value = false
}

// 显示新增弹窗
const showCreateModal = async () => {
  try {
    // 模拟获取字段定义
    await new Promise(resolve => setTimeout(resolve, 500))
    fields.value = [
      // 基本信息
      {
        name: 'companyName',
        label: '企业名称',
        fieldType: 'text',
        required: true,
        sort: 1
      },
      {
        name: 'companyCode',
        label: '企业编码',
        fieldType: 'text',
        required: true,
        sort: 2
      },
      {
        name: 'landId',
        label: '所属土地',
        fieldType: 'select',
        required: true,
        sort: 3
      },
      {
        name: 'assetCode',
        label: '资产编码',
        fieldType: 'text',
        required: true,
        sort: 4
      },
      {
        name: 'propertyName',
        label: '房产名称',
        fieldType: 'text',
        required: true,
        sort: 5
      },
      // 地址信息
      {
        name: 'province',
        label: '省（自治区、直辖市）',
        fieldType: 'select',
        required: true,
        options: ['浙江省', '江苏省', '上海市'],
        sort: 6
      },
      {
        name: 'city',
        label: '市（地、州、盟）',
        fieldType: 'select',
        required: true,
        options: ['杭州市', '宁波市', '温州市'],
        sort: 7
      },
      {
        name: 'district',
        label: '区/县',
        fieldType: 'select',
        required: true,
        options: ['西湖区', '滨江区', '余杭区'],
        sort: 8
      },
      {
        name: 'address',
        label: '房产具体位置',
        fieldType: 'text',
        required: true,
        sort: 9
      },
      {
        name: 'coordinates',
        label: '经纬度',
        fieldType: 'text',
        required: true,
        sort: 10
      },
      // 房产信息
      {
        name: 'source',
        label: '来源',
        fieldType: 'select',
        required: true,
        options: ['自建', '购置', '划拨', '其他'],
        sort: 11
      },
      {
        name: 'investmentSource',
        label: '投资来源',
        fieldType: 'select',
        required: true,
        options: ['自有资金', '银行贷款', '财政拨款', '其他'],
        sort: 12
      },
      {
        name: 'propertyType',
        label: '房产分类',
        fieldType: 'select',
        required: true,
        options: ['办公用房', '经营用房', '住宅', '其他'],
        sort: 13
      },
      {
        name: 'buildYear',
        label: '建成年份',
        fieldType: 'number',
        required: true,
        sort: 14
      },
      {
        name: 'floors',
        label: '建筑层数',
        fieldType: 'number',
        required: true,
        sort: 15
      },
      // 面积信息
      {
        name: 'buildingArea',
        label: '建筑面积（平方米）',
        fieldType: 'number',
        required: true,
        sort: 16
      },
      {
        name: 'usableArea',
        label: '可使用面积（平方米）',
        fieldType: 'number',
        required: true,
        sort: 17
      },
      {
        name: 'usedArea',
        label: '已使用面积（平方米）',
        fieldType: 'number',
        sort: 18
      },
      {
        name: 'selfUsedArea',
        label: '自用面积（平方米）',
        fieldType: 'number',
        required: true,
        sort: 19
      },
      {
        name: 'rentedArea',
        label: '出租面积（平方米）',
        fieldType: 'number',
        required: true,
        sort: 20
      },
      {
        name: 'occupiedArea',
        label: '被占用面积（平方米）',
        fieldType: 'number',
        required: true,
        sort: 21
      },
      {
        name: 'idleArea',
        label: '闲置面积（平方米）',
        fieldType: 'number',
        sort: 22
      },
      // 权证信息
      {
        name: 'hasCertificate',
        label: '是否有证',
        fieldType: 'select',
        required: true,
        options: ['是', '否'],
        sort: 23
      },
      {
        name: 'certificateHolder',
        label: '房产证载人名称',
        fieldType: 'text',
        sort: 24
      },
      {
        name: 'certificateNumber',
        label: '房产（不动产）权证号',
        fieldType: 'text',
        sort: 25
      },
      // 资产信息
      {
        name: 'originalValue',
        label: '资产原值(元）',
        fieldType: 'number',
        sort: 26
      },
      {
        name: 'netValue',
        label: '资产净值（元）',
        fieldType: 'number',
        sort: 27
      },
      {
        name: 'usage',
        label: '资产用途',
        fieldType: 'text',
        sort: 28
      },
      // 其他信息
      {
        name: 'accountingSubject',
        label: '核算科目',
        fieldType: 'text',
        sort: 29
      },
      {
        name: 'isNewThisYear',
        label: '是否为本年新增',
        fieldType: 'select',
        options: ['是', '否'],
        sort: 30
      },
      {
        name: 'remarks',
        label: '备注',
        fieldType: 'textarea',
        sort: 31
      }
    ]
    
    // 初始化表单状态
    const newFormState: Record<string, any> = {}
    fields.value.forEach(field => {
      newFormState[field.name] = undefined
    })
    Object.assign(formState, newFormState)
    
    modalTitle.value = '申报房产'
    modalVisible.value = true
  } catch (error) {
    message.error('获取字段定义失败')
  }
}

// 显示编辑弹窗
const showEditModal = (record: any) => {
  modalTitle.value = '编辑房产'
  Object.assign(formState, record)
  modalVisible.value = true
}

// 显示详情弹窗
const showDetailModal = (record: any) => {
  // TODO: 实现详情查看功能
  console.log('查看详情:', record)
}

// 弹窗确认
const handleModalOk = () => {
  formRef.value.validate().then(() => {
    // TODO: 调用后端API保存房产信息
    message.success('保存成功')
    modalVisible.value = false
    fetchPropertyList()
  })
}

// 弹窗取消
const handleModalCancel = () => {
  modalVisible.value = false
  formRef.value.resetFields()
}

// 显示高级搜索
const showAdvancedSearch = () => {
  searchDrawerVisible.value = true
}

// 重置高级搜索
const resetAdvancedSearch = () => {
  Object.assign(advancedSearch, {
    status: [],
    purpose: [],
    minArea: undefined,
    maxArea: undefined,
    department: []
  })
}

// 处理高级搜索
const handleAdvancedSearch = () => {
  // TODO: 实现高级搜索功能
  console.log('高级搜索条件:', advancedSearch)
  searchDrawerVisible.value = false
  fetchPropertyList()
}

// 处理表格变化
const handleTableChange = (pagination: any) => {
  console.log('分页变化:', pagination)
  fetchPropertyList()
}

// 处理搜索
const onSearch = (value: string) => {
  console.log('搜索关键字:', value)
  fetchPropertyList()
}

// 获取状态样式类
const getStatusClass = (status: string) => {
  const map: Record<string, string> = {
    '闲置': 'status-idle',
    '使用中': 'status-inuse',
    '维护中': 'status-maintenance'
  }
  return ['status-tag', map[status]]
}

// 文件上传相关
const uploadAction = '/api/upload'
const beforeUpload = (file: File) => {
  // TODO: 实现文件上传前的验证
  return true
}

// 初始化
fetchPropertyList()
</script>

<style lang="scss" scoped>
.property-list {
  .page-header {
    margin-bottom: $spacing-lg;
    
    h2 {
      color: $text-primary;
      margin-bottom: $spacing-md;
      font-size: 24px;
    }
  }

  .header-actions {
    margin-bottom: $spacing-md;
  }

  .custom-button {
    background: $primary-color;
    border-color: $primary-color;
    border-radius: $border-radius-md;
    
    &:hover {
      background: darken($primary-color, 5%);
      border-color: darken($primary-color, 5%);
    }
  }

  .custom-card {
    border-radius: $border-radius-lg;
    box-shadow: $shadow-sm;
  }

  .custom-table {
    :deep(.ant-table-thead > tr > th) {
      background: $background-light;
      color: $text-primary;
    }
    
    :deep(.ant-table-tbody > tr > td) {
      color: $text-secondary;
    }
  }

  .status-tag {
    border-radius: $border-radius-sm;
    padding: 4px 12px;
    
    &.status-idle {
      background: rgba($warning-color, 0.1);
      color: darken($warning-color, 20%);
      border-color: $warning-color;
    }
    
    &.status-inuse {
      background: rgba($success-color, 0.1);
      color: darken($success-color, 20%);
      border-color: $success-color;
    }
    
    &.status-maintenance {
      background: rgba($error-color, 0.1);
      color: darken($error-color, 20%);
      border-color: $error-color;
    }
  }

  .action-link {
    color: $primary-color;
    
    &:hover {
      color: darken($primary-color, 10%);
    }
  }

  .drawer-footer {
    position: absolute;
    bottom: 0;
    width: 100%;
    border-top: 1px solid $border-color;
    padding: $spacing-md;
    text-align: right;
    left: 0;
    background: white;
  }
}
</style> 