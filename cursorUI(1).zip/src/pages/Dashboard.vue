<template>
  <div class="dashboard">
    <div class="page-header">
      <h2>仪表盘</h2>
    </div>
    
    <div class="stats-cards">
      <a-row :gutter="16" class="stat-cards">
        <a-col :span="6">
          <a-card>
            <a-statistic
              title="总房产数量"
              :value="156"
              :value-style="{ color: '#3f8600' }"
            >
              <template #prefix>
                <HomeOutlined />
              </template>
            </a-statistic>
          </a-card>
        </a-col>
        <a-col :span="6">
          <a-card>
            <a-statistic
              title="使用中房产"
              :value="132"
              :value-style="{ color: '#1890ff' }"
            >
              <template #prefix>
                <CheckCircleOutlined />
              </template>
            </a-statistic>
          </a-card>
        </a-col>
        <a-col :span="6">
          <a-card>
            <a-statistic
              title="维修中房产"
              :value="8"
              :value-style="{ color: '#faad14' }"
            >
              <template #prefix>
                <ToolOutlined />
              </template>
            </a-statistic>
          </a-card>
        </a-col>
        <a-col :span="6">
          <a-card>
            <a-statistic
              title="闲置房产"
              :value="16"
              :value-style="{ color: '#cf1322' }"
            >
              <template #prefix>
                <WarningOutlined />
              </template>
            </a-statistic>
          </a-card>
        </a-col>
      </a-row>
    </div>

    <a-row :gutter="16" class="charts-row">
      <a-col :span="8">
        <a-card class="chart-card" title="房产占用率">
          <!-- 这里可以添加房产占用率图表 -->
          <div class="chart-placeholder">
            占用率图表
          </div>
        </a-card>
      </a-col>
    </a-row>

    <a-row :gutter="16" class="charts-row">
      <a-col :span="12">
        <a-card class="chart-card" title="维修工单状态">
          <!-- 这里可以添加维修工单状态图表 -->
          <div class="chart-placeholder">
            工单状态图表
          </div>
        </a-card>
      </a-col>
    </a-row>

    <!-- 最近活动 -->
    <a-card title="最近活动" class="activity-card">
      <a-timeline>
        <a-timeline-item v-for="activity in activities" :key="activity.id">
          <template #dot>
            <component :is="activity.icon" :style="{ color: activity.color }" />
          </template>
          <div class="activity-content">
            <div class="activity-title">{{ activity.title }}</div>
            <div class="activity-time">{{ activity.time }}</div>
          </div>
        </a-timeline-item>
      </a-timeline>
    </a-card>
  </div>
</template>

<script lang="ts" setup>
import {
  HomeOutlined,
  CheckCircleOutlined,
  ToolOutlined,
  WarningOutlined,
  FileTextOutlined,
  SyncOutlined,
  AlertOutlined
} from '@ant-design/icons-vue'

const activities = [
  {
    id: 1,
    title: '完成3号楼会议室维护保养',
    time: '2024-01-15 14:30',
    icon: CheckCircleOutlined,
    color: '#52c41a'
  },
  {
    id: 2,
    title: '5号楼办公室设备检查',
    time: '2024-01-15 11:20',
    icon: FileTextOutlined,
    color: '#1890ff'
  },
  {
    id: 3,
    title: '2号楼空调系统维修',
    time: '2024-01-15 09:15',
    icon: ToolOutlined,
    color: '#faad14'
  },
  {
    id: 4,
    title: '1号楼消防设施年检',
    time: '2024-01-14 16:45',
    icon: AlertOutlined,
    color: '#ff4d4f'
  },
  {
    id: 5,
    title: '4号楼资产盘点完成',
    time: '2024-01-14 15:00',
    icon: SyncOutlined,
    color: '#722ed1'
  }
]
</script>

<style lang="scss" scoped>
.dashboard {
  .page-header {
    margin-bottom: $spacing-lg;
    
    h2 {
      color: $text-primary;
      margin-bottom: $spacing-md;
      font-size: 24px;
    }
  }

  .stats-cards {
    margin-bottom: $spacing-xl;
  }

  .stat-cards {
    margin-bottom: 24px;
  }

  .activity-card {
    .activity-content {
      .activity-title {
        color: rgba(0, 0, 0, 0.85);
        margin-bottom: 4px;
      }

      .activity-time {
        color: rgba(0, 0, 0, 0.45);
        font-size: 12px;
      }
    }
  }

  .charts-row {
    margin-bottom: $spacing-lg;
  }

  .chart-card {
    border-radius: $border-radius-lg;
    box-shadow: $shadow-sm;
    
    :deep(.ant-card-head) {
      border-bottom: 1px solid $border-color;
      
      .ant-card-head-title {
        color: $text-primary;
        font-size: 16px;
      }
    }
  }

  .chart-placeholder {
    height: 300px;
    display: flex;
    align-items: center;
    justify-content: center;
    background: $background-light;
    border-radius: $border-radius-md;
    color: $text-secondary;
    font-size: 16px;
  }
}
</style> 