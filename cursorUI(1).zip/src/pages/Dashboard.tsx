import React from 'react';
import { Row, Col, Card, Statistic } from 'antd';
import { 
  HomeOutlined, 
  TeamOutlined,
  AlertOutlined,
  DollarOutlined 
} from '@ant-design/icons';

const Dashboard: React.FC = () => {
  return (
    <div className="dashboard">
      <h2>仪表盘</h2>
      
      <Row gutter={16}>
        <Col span={6}>
          <Card>
            <Statistic
              title="总房产数量"
              value={156}
              prefix={<HomeOutlined />}
            />
          </Card>
        </Col>
        
        <Col span={6}>
          <Card>
            <Statistic
              title="在租房产"
              value={89}
              prefix={<TeamOutlined />}
            />
          </Card>
        </Col>
        
        <Col span={6}>
          <Card>
            <Statistic
              title="待处理维修"
              value={12}
              prefix={<AlertOutlined />}
            />
          </Card>
        </Col>
        
        <Col span={6}>
          <Card>
            <Statistic
              title="本月收入(万元)"
              value={256.8}
              prefix={<DollarOutlined />}
            />
          </Card>
        </Col>
      </Row>
      
      {/* 这里可以添加更多的图表组件，如:
         - 收入趋势图
         - 房产占用率统计
         - 维修工单状态
         - 租客分布等
      */}
    </div>
  );
};

export default Dashboard; 