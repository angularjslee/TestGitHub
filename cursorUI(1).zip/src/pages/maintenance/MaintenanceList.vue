<template>
  <div class="maintenance-list">
    <div class="page-header">
      <h2>维护管理</h2>
      <div class="header-actions">
        <a-space>
          <a-button type="primary" @click="showCreatePlanModal" class="custom-button">
            <template #icon><PlusOutlined /></template>
            制定维护计划
          </a-button>
          <a-button type="primary" @click="showRepairModal" class="custom-button">
            <template #icon><ToolOutlined /></template>
            报修申请
          </a-button>
          <a-input-search
            v-model:value="searchText"
            placeholder="搜索房产编号/维护内容"
            style="width: 250px"
            @search="onSearch"
          />
          <a-button @click="showAdvancedSearch">
            <template #icon><FilterOutlined /></template>
            高级筛选
          </a-button>
        </a-space>
      </div>
    </div>

    <!-- 维护计划列表 -->
    <a-card class="custom-card" title="维护计划">
      <a-table
        :columns="planColumns"
        :data-source="maintenancePlans"
        :loading="loading"
        class="custom-table"
      >
        <!-- 状态列 -->
        <template #status="{ text }">
          <a-tag :class="getPlanStatusClass(text)">
            {{ text }}
          </a-tag>
        </template>

        <!-- 操作列 -->
        <template #action="{ record }">
          <a-space>
            <a class="action-link" @click="showPlanDetailModal(record)">查看</a>
            <a-divider type="vertical" />
            <a class="action-link" @click="showEditPlanModal(record)">编辑</a>
            <a-divider type="vertical" />
            <a-popconfirm
              title="确定要删除该维护计划吗？"
              @confirm="handleDeletePlan(record)"
            >
              <a class="action-link">删除</a>
            </a-popconfirm>
          </a-space>
        </template>
      </a-table>
    </a-card>

    <!-- 维修申请列表 -->
    <a-card class="custom-card" title="维修申请" style="margin-top: 20px;">
      <a-table
        :columns="repairColumns"
        :data-source="repairRequests"
        :loading="loading"
        class="custom-table"
      >
        <!-- 紧急程度列 -->
        <template #urgency="{ text }">
          <a-tag :class="getUrgencyClass(text)">
            {{ text }}
          </a-tag>
        </template>

        <!-- 状态列 -->
        <template #repairStatus="{ text }">
          <a-tag :class="getRepairStatusClass(text)">
            {{ text }}
          </a-tag>
        </template>

        <!-- 操作列 -->
        <template #repairAction="{ record }">
          <a-space>
            <a class="action-link" @click="showRepairDetailModal(record)">查看</a>
            <a-divider type="vertical" />
            <a class="action-link" @click="showUpdateStatusModal(record)">更新状态</a>
            <a-divider type="vertical" />
            <a class="action-link" @click="showEvaluateModal(record)">评价</a>
          </a-space>
        </template>
      </a-table>
    </a-card>

    <!-- 制定维护计划弹窗 -->
    <a-modal
      v-model:visible="planModalVisible"
      :title="planModalTitle"
      width="800px"
      @ok="handlePlanModalOk"
      @cancel="handlePlanModalCancel"
      class="custom-modal"
    >
      <a-form
        ref="planFormRef"
        :model="planFormState"
        :rules="planRules"
        :label-col="{ span: 6 }"
        :wrapper-col="{ span: 16 }"
        class="custom-form"
      >
        <a-form-item label="房产" name="propertyId" required>
          <a-select
            v-model:value="planFormState.propertyId"
            placeholder="请选择房产"
            show-search
            :options="propertyOptions"
          />
        </a-form-item>

        <a-form-item label="维护周期" name="cycle" required>
          <a-select v-model:value="planFormState.cycle" placeholder="请选择维护周期">
            <a-select-option value="weekly">每周</a-select-option>
            <a-select-option value="monthly">每月</a-select-option>
            <a-select-option value="quarterly">每季度</a-select-option>
            <a-select-option value="yearly">每年</a-select-option>
          </a-select>
        </a-form-item>

        <a-form-item label="维护时间" name="maintenanceTime" required>
          <a-date-picker
            v-model:value="planFormState.maintenanceTime"
            style="width: 100%"
            show-time
          />
        </a-form-item>

        <a-form-item label="维护内容" name="content" required>
          <a-textarea
            v-model:value="planFormState.content"
            :rows="4"
            placeholder="请输入维护内容"
          />
        </a-form-item>

        <a-form-item label="负责人员" name="responsiblePerson" required>
          <a-select
            v-model:value="planFormState.responsiblePerson"
            mode="multiple"
            placeholder="请选择负责人员"
            :options="staffOptions"
          />
        </a-form-item>

        <a-form-item label="所需资源" name="resources">
          <a-textarea
            v-model:value="planFormState.resources"
            :rows="3"
            placeholder="请输入所需资源"
          />
        </a-form-item>
      </a-form>
    </a-modal>

    <!-- 报修申请弹窗 -->
    <a-modal
      v-model:visible="repairModalVisible"
      title="报修申请"
      width="800px"
      @ok="handleRepairModalOk"
      @cancel="handleRepairModalCancel"
      class="custom-modal"
    >
      <a-form
        ref="repairFormRef"
        :model="repairFormState"
        :rules="repairRules"
        :label-col="{ span: 6 }"
        :wrapper-col="{ span: 16 }"
        class="custom-form"
      >
        <a-form-item label="房产" name="propertyId" required>
          <a-select
            v-model:value="repairFormState.propertyId"
            placeholder="请选择房产"
            show-search
            :options="propertyOptions"
          />
        </a-form-item>

        <a-form-item label="故障描述" name="description" required>
          <a-textarea
            v-model:value="repairFormState.description"
            :rows="4"
            placeholder="请详细描述故障情况"
          />
        </a-form-item>

        <a-form-item label="故障位置" name="location" required>
          <a-input v-model:value="repairFormState.location" placeholder="请输入具体故障位置" />
        </a-form-item>

        <a-form-item label="紧急程度" name="urgency" required>
          <a-select v-model:value="repairFormState.urgency" placeholder="请选择紧急程度">
            <a-select-option value="high">紧急</a-select-option>
            <a-select-option value="medium">一般</a-select-option>
            <a-select-option value="low">低级</a-select-option>
          </a-select>
        </a-form-item>

        <a-form-item label="预期维修时间" name="expectedTime">
          <a-range-picker
            v-model:value="repairFormState.expectedTime"
            show-time
            style="width: 100%"
          />
        </a-form-item>

        <a-form-item label="图片附件" name="attachments">
          <a-upload
            v-model:fileList="repairFormState.attachments"
            :action="uploadAction"
            list-type="picture-card"
            :before-upload="beforeUpload"
          >
            <div>
              <plus-outlined />
              <div style="margin-top: 8px">上传</div>
            </div>
          </a-upload>
        </a-form-item>
      </a-form>
    </a-modal>

    <!-- 高级搜索抽屉 -->
    <a-drawer
      v-model:visible="searchDrawerVisible"
      title="高级搜索"
      placement="right"
      width="400"
    >
      <!-- 搜索表单内容 -->
    </a-drawer>
  </div>
</template>

<script lang="ts" setup>
import { ref, reactive } from 'vue'
import { message } from 'ant-design-vue'
import type { TableColumnsType } from 'ant-design-vue'
import {
  PlusOutlined,
  ToolOutlined,
  FilterOutlined
} from '@ant-design/icons-vue'

// 维护计划表格列定义
const planColumns: TableColumnsType = [
  {
    title: '房产编号',
    dataIndex: 'propertyId',
    key: 'propertyId',
  },
  {
    title: '维护内容',
    dataIndex: 'content',
    key: 'content',
  },
  {
    title: '维护周期',
    dataIndex: 'cycle',
    key: 'cycle',
  },
  {
    title: '维护时间',
    dataIndex: 'maintenanceTime',
    key: 'maintenanceTime',
  },
  {
    title: '负责人员',
    dataIndex: 'responsiblePerson',
    key: 'responsiblePerson',
  },
  {
    title: '状态',
    dataIndex: 'status',
    key: 'status',
    slots: { customRender: 'status' }
  },
  {
    title: '操作',
    key: 'action',
    slots: { customRender: 'action' }
  }
]

// 维修申请表格列定义
const repairColumns: TableColumnsType = [
  {
    title: '房产编号',
    dataIndex: 'propertyId',
    key: 'propertyId',
  },
  {
    title: '故障描述',
    dataIndex: 'description',
    key: 'description',
  },
  {
    title: '故障位置',
    dataIndex: 'location',
    key: 'location',
  },
  {
    title: '紧急程度',
    dataIndex: 'urgency',
    key: 'urgency',
    slots: { customRender: 'urgency' }
  },
  {
    title: '申请时间',
    dataIndex: 'createTime',
    key: 'createTime',
  },
  {
    title: '状态',
    dataIndex: 'status',
    key: 'status',
    slots: { customRender: 'repairStatus' }
  },
  {
    title: '操作',
    key: 'action',
    slots: { customRender: 'repairAction' }
  }
]

// 表格数据
const loading = ref(false)
const maintenancePlans = ref([])
const repairRequests = ref([])

// 搜索相关
const searchText = ref('')
const searchDrawerVisible = ref(false)

// 维护计划表单相关
const planFormRef = ref()
const planModalVisible = ref(false)
const planModalTitle = ref('制定维护计划')
const planFormState = reactive({
  propertyId: undefined,
  cycle: undefined,
  maintenanceTime: undefined,
  content: '',
  responsiblePerson: [],
  resources: ''
})

// 维修申请表单相关
const repairFormRef = ref()
const repairModalVisible = ref(false)
const repairFormState = reactive({
  propertyId: undefined,
  description: '',
  location: '',
  urgency: undefined,
  expectedTime: [],
  attachments: []
})

// 模拟房产选项
const propertyOptions = [
  { value: '1', label: '杭州市西湖区xxx路xx号-A101' },
  { value: '2', label: '杭州市西湖区xxx路xx号-A102' }
]

// 模拟员工选项
const staffOptions = [
  { value: '1', label: '张三' },
  { value: '2', label: '李四' }
]

// 获取维护计划列表
const fetchMaintenancePlans = async () => {
  loading.value = true
  try {
    // TODO: 调用后端API获取维护计划列表
    maintenancePlans.value = [
      {
        id: '1',
        propertyId: '1',
        content: '空调系统维护',
        cycle: '每月',
        maintenanceTime: '2024-03-01 10:00:00',
        responsiblePerson: '张三',
        status: '待执行'
      }
    ]
  } catch (error) {
    message.error('获取维护计划列表失败')
  }
  loading.value = false
}

// 获取维修申请列表
const fetchRepairRequests = async () => {
  loading.value = true
  try {
    // TODO: 调用后端API获取维修申请列表
    repairRequests.value = [
      {
        id: '1',
        propertyId: '1',
        description: '空调不制冷',
        location: 'A101会议室',
        urgency: 'high',
        createTime: '2024-03-22 14:30:00',
        status: '待处理'
      }
    ]
  } catch (error) {
    message.error('获取维修申请列表失败')
  }
  loading.value = false
}

// 显示创建维护计划弹窗
const showCreatePlanModal = () => {
  planModalTitle.value = '制定维护计划'
  planModalVisible.value = true
}

// 显示编辑维护计划弹窗
const showEditPlanModal = (record: any) => {
  planModalTitle.value = '编辑维护计划'
  Object.assign(planFormState, record)
  planModalVisible.value = true
}

// 显示维护计划详情
const showPlanDetailModal = (record: any) => {
  // TODO: 实现详情查看功能
  console.log('查看维护计划:', record)
}

// 删除维护计划
const handleDeletePlan = async (record: any) => {
  try {
    // TODO: 调用后端API删除维护计划
    message.success('删除成功')
    fetchMaintenancePlans()
  } catch (error) {
    message.error('删除失败')
  }
}

// 显示报修申请弹窗
const showRepairModal = () => {
  repairModalVisible.value = true
}

// 显示维修详情
const showRepairDetailModal = (record: any) => {
  // TODO: 实现详情查看功能
  console.log('查看维修详情:', record)
}

// 显示更新状态弹窗
const showUpdateStatusModal = (record: any) => {
  // TODO: 实现状态更新功能
  console.log('更新维修状态:', record)
}

// 显示评价弹窗
const showEvaluateModal = (record: any) => {
  // TODO: 实现评价功能
  console.log('评价维修:', record)
}

// 维护计划弹窗确认
const handlePlanModalOk = () => {
  planFormRef.value.validate().then(() => {
    // TODO: 调用后端API保存维护计划
    message.success('保存成功')
    planModalVisible.value = false
    fetchMaintenancePlans()
  })
}

// 维护计划弹窗取消
const handlePlanModalCancel = () => {
  planModalVisible.value = false
  planFormRef.value.resetFields()
}

// 维修申请弹窗确认
const handleRepairModalOk = () => {
  repairFormRef.value.validate().then(() => {
    // TODO: 调用后端API保存维修申请
    message.success('申请成功')
    repairModalVisible.value = false
    fetchRepairRequests()
  })
}

// 维修申请弹窗取消
const handleRepairModalCancel = () => {
  repairModalVisible.value = false
  repairFormRef.value.resetFields()
}

// 显示高级搜索
const showAdvancedSearch = () => {
  searchDrawerVisible.value = true
}

// 处理搜索
const onSearch = (value: string) => {
  console.log('搜索关键字:', value)
  fetchMaintenancePlans()
  fetchRepairRequests()
}

// 获取维护计划状态样式类
const getPlanStatusClass = (status: string) => {
  const map: Record<string, string> = {
    '待执行': 'status-pending',
    '执行中': 'status-processing',
    '已完成': 'status-completed',
    '已取消': 'status-cancelled'
  }
  return ['status-tag', map[status]]
}

// 获取紧急程度样式类
const getUrgencyClass = (urgency: string) => {
  const map: Record<string, string> = {
    'high': 'urgency-high',
    'medium': 'urgency-medium',
    'low': 'urgency-low'
  }
  return ['urgency-tag', map[urgency]]
}

// 获取维修状态样式类
const getRepairStatusClass = (status: string) => {
  const map: Record<string, string> = {
    '待处理': 'status-pending',
    '处理中': 'status-processing',
    '已完成': 'status-completed',
    '已评价': 'status-evaluated'
  }
  return ['status-tag', map[status]]
}

// 文件上传相关
const uploadAction = '/api/upload'
const beforeUpload = (file: File) => {
  // TODO: 实现文件上传前的验证
  return true
}

// 初始化
fetchMaintenancePlans()
fetchRepairRequests()
</script>

<style lang="scss" scoped>
.maintenance-list {
  .page-header {
    margin-bottom: $spacing-lg;
    
    h2 {
      color: $text-primary;
      margin-bottom: $spacing-md;
      font-size: 24px;
    }
  }

  .header-actions {
    margin-bottom: $spacing-md;
  }

  .custom-button {
    background: $primary-color;
    border-color: $primary-color;
    border-radius: $border-radius-md;
    
    &:hover {
      background: darken($primary-color, 5%);
      border-color: darken($primary-color, 5%);
    }
  }

  .custom-card {
    border-radius: $border-radius-lg;
    box-shadow: $shadow-sm;
  }

  .custom-table {
    :deep(.ant-table-thead > tr > th) {
      background: $background-light;
      color: $text-primary;
    }
    
    :deep(.ant-table-tbody > tr > td) {
      color: $text-secondary;
    }
  }

  .status-tag {
    border-radius: $border-radius-sm;
    padding: 4px 12px;
    
    &.status-pending {
      background: rgba($warning-color, 0.1);
      color: darken($warning-color, 20%);
      border-color: $warning-color;
    }
    
    &.status-processing {
      background: rgba($primary-color, 0.1);
      color: darken($primary-color, 20%);
      border-color: $primary-color;
    }
    
    &.status-completed {
      background: rgba($success-color, 0.1);
      color: darken($success-color, 20%);
      border-color: $success-color;
    }
    
    &.status-cancelled {
      background: rgba($error-color, 0.1);
      color: darken($error-color, 20%);
      border-color: $error-color;
    }
    
    &.status-evaluated {
      background: rgba($secondary-color, 0.1);
      color: darken($secondary-color, 20%);
      border-color: $secondary-color;
    }
  }

  .urgency-tag {
    border-radius: $border-radius-sm;
    padding: 4px 12px;
    
    &.urgency-high {
      background: rgba($error-color, 0.1);
      color: darken($error-color, 20%);
      border-color: $error-color;
    }
    
    &.urgency-medium {
      background: rgba($warning-color, 0.1);
      color: darken($warning-color, 20%);
      border-color: $warning-color;
    }
    
    &.urgency-low {
      background: rgba($success-color, 0.1);
      color: darken($success-color, 20%);
      border-color: $success-color;
    }
  }

  .action-link {
    color: $primary-color;
    
    &:hover {
      color: darken($primary-color, 10%);
    }
  }
}
</style> 