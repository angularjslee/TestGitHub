<template>
  <div class="land-list">
    <div class="page-header">
      <h2>土地资源管理</h2>
    </div>

    <div class="header-actions">
      <a-space>
        <a-button type="primary" @click="showCreateModal" class="custom-button">
          <template #icon><PlusOutlined /></template>
          申报土地
        </a-button>
        <a-input-search
          v-model:value="searchText"
          placeholder="搜索编号/位置/用途"
          class="custom-search"
          @search="onSearch"
        />
        <a-button @click="showAdvancedSearch">
          <template #icon><FilterOutlined /></template>
          高级筛选
        </a-button>
      </a-space>
    </div>

    <a-card class="custom-card">
      <a-table
        :columns="columns"
        :data-source="landList"
        :loading="loading"
        :pagination="pagination"
        @change="handleTableChange"
        class="custom-table"
      >
        <!-- 状态列 -->
        <template #status="{ text }">
          <a-tag :class="getStatusClass(text)">
            {{ text }}
          </a-tag>
        </template>

        <!-- 操作列 -->
        <template #action="{ record }">
          <a-space>
            <a class="action-link" @click="showDetailModal(record)">查看</a>
            <a-divider type="vertical" />
            <a class="action-link" @click="showEditModal(record)">编辑</a>
            <a-divider type="vertical" />
            <a class="action-link" @click="showHistoryModal(record)">使用记录</a>
          </a-space>
        </template>
      </a-table>
    </a-card>

    <!-- 土地申报/编辑弹窗 -->
    <a-modal
      v-model:visible="modalVisible"
      :title="modalTitle"
      width="800px"
      @ok="handleModalOk"
      @cancel="handleModalCancel"
      class="custom-modal"
    >
      <a-form
        ref="formRef"
        :model="formState"
        :rules="rules"
        :label-col="{ span: 6 }"
        :wrapper-col="{ span: 16 }"
        class="custom-form"
      >
        <template v-for="group in groupedFields" :key="group.title">
          <a-divider>{{ group.title }}</a-divider>
          <template v-for="field in group.fields" :key="field.name">
            <a-form-item
              :label="field.label"
              :name="field.name"
              :required="field.required"
            >
              <!-- 文本输入 -->
              <a-input
                v-if="field.fieldType === 'text'"
                v-model:value="formState[field.name]"
                :placeholder="`请输入${field.label}`"
                :disabled="isEdit && field.name === 'code'"
              />
              
              <!-- 数字输入 -->
              <a-input-number
                v-else-if="field.fieldType === 'number'"
                v-model:value="formState[field.name]"
                :precision="2"
                :min="0"
                style="width: 100%"
                :placeholder="`请输入${field.label}`"
              />
              
              <!-- 下拉选择 -->
              <a-select
                v-else-if="field.fieldType === 'select'"
                v-model:value="formState[field.name]"
                :placeholder="`请选择${field.label}`"
              >
                <a-select-option
                  v-for="option in field.options"
                  :key="option"
                  :value="option"
                >
                  {{ option }}
                </a-select-option>
              </a-select>
              
              <!-- 日期选择 -->
              <a-date-picker
                v-else-if="field.fieldType === 'date'"
                v-model:value="formState[field.name]"
                style="width: 100%"
                :placeholder="`请选择${field.label}`"
              />
              
              <!-- 多行文本 -->
              <a-textarea
                v-else-if="field.fieldType === 'textarea'"
                v-model:value="formState[field.name]"
                :rows="3"
                :placeholder="`请输入${field.label}`"
              />
            </a-form-item>
          </template>
        </template>
      </a-form>
    </a-modal>

    <!-- 高级搜索抽屉 -->
    <a-drawer
      v-model:visible="searchDrawerVisible"
      title="高级搜索"
      width="400px"
      @close="searchDrawerVisible = false"
    >
      <a-form layout="vertical">
        <a-form-item label="使用状态">
          <a-select
            v-model:value="advancedSearch.status"
            mode="multiple"
            placeholder="请选择使用状态"
            style="width: 100%"
          >
            <a-select-option value="idle">闲置</a-select-option>
            <a-select-option value="inUse">使用中</a-select-option>
            <a-select-option value="reserved">已预留</a-select-option>
          </a-select>
        </a-form-item>

        <a-form-item label="土地用途">
          <a-select
            v-model:value="advancedSearch.purpose"
            mode="multiple"
            placeholder="请选择土地用途"
            style="width: 100%"
          >
            <a-select-option value="commercial">商业用地</a-select-option>
            <a-select-option value="industrial">工业用地</a-select-option>
            <a-select-option value="residential">住宅用地</a-select-option>
            <a-select-option value="office">办公用地</a-select-option>
          </a-select>
        </a-form-item>

        <a-form-item label="面积范围">
          <a-space>
            <a-input-number
              v-model:value="advancedSearch.minArea"
              placeholder="最小面积"
              style="width: 150px"
            />
            <span>-</span>
            <a-input-number
              v-model:value="advancedSearch.maxArea"
              placeholder="最大面积"
              style="width: 150px"
            />
          </a-space>
        </a-form-item>

        <a-form-item label="管理部门">
          <a-select
            v-model:value="advancedSearch.department"
            mode="multiple"
            placeholder="请选择管理部门"
            style="width: 100%"
          >
            <a-select-option v-for="dept in departments" :key="dept.id" :value="dept.id">
              {{ dept.name }}
            </a-select-option>
          </a-select>
        </a-form-item>
      </a-form>

      <div class="drawer-footer">
        <a-space>
          <a-button @click="resetAdvancedSearch">重置</a-button>
          <a-button type="primary" @click="handleAdvancedSearch">确定</a-button>
        </a-space>
      </div>
    </a-drawer>
  </div>
</template>

<script lang="ts" setup>
import { ref, reactive, computed } from 'vue'
import { message } from 'ant-design-vue'
import {
  PlusOutlined,
  FilterOutlined,
  UploadOutlined
} from '@ant-design/icons-vue'
import type { TableColumnsType } from 'ant-design-vue'
import type { FieldDefinition } from '@/types/system'

// 表格列定义
const columns: TableColumnsType = [
  {
    title: '土地编号',
    dataIndex: 'code',
    key: 'code',
  },
  {
    title: '位置',
    dataIndex: 'location',
    key: 'location',
  },
  {
    title: '面积(㎡)',
    dataIndex: 'area',
    key: 'area',
  },
  {
    title: '用途',
    dataIndex: 'purposeName',
    key: 'purposeName',
  },
  {
    title: '状态',
    dataIndex: 'status',
    key: 'status',
    slots: { customRender: 'status' }
  },
  {
    title: '操作',
    key: 'action',
    slots: { customRender: 'action' }
  }
]

// 表格数据
const loading = ref(false)
const landList = ref([
  {
    id: 1,
    code: 'L2024001',
    location: '杭州市西湖区xxx路xx号',
    area: 5000.00,
    purpose: 'commercial',
    purposeName: '商业用地',
    status: '使用中',
    ownership: '国有土地',
    remarks: '临街商业用地'
  }
])

// 分页配置
const pagination = reactive({
  current: 1,
  pageSize: 10,
  total: 0,
  showSizeChanger: true,
  showQuickJumper: true
})

// 搜索
const searchText = ref('')
const onSearch = (value: string) => {
  console.log('搜索:', value)
  fetchLandList()
}

// 表单相关
const modalVisible = ref(false)
const modalTitle = ref('新增土地')
const isEdit = ref(false)
const formRef = ref()

// 获取字段定义
const fields = ref<FieldDefinition[]>([])

// 按组分类的字段
const groupedFields = computed(() => {
  const groups = [
    { title: '基本信息', fields: [] },
    { title: '位置信息', fields: [] },
    { title: '土地信息', fields: [] },
    { title: '面积信息', fields: [] },
    { title: '权证信息', fields: [] },
    { title: '资产信息', fields: [] },
    { title: '其他信息', fields: [] }
  ]
  
  fields.value.forEach(field => {
    if (field.sort <= 4) {
      groups[0].fields.push(field)
    } else if (field.sort <= 9) {
      groups[1].fields.push(field)
    } else if (field.sort <= 14) {
      groups[2].fields.push(field)
    } else if (field.sort <= 17) {
      groups[3].fields.push(field)
    } else if (field.sort <= 20) {
      groups[4].fields.push(field)
    } else if (field.sort <= 23) {
      groups[5].fields.push(field)
    } else {
      groups[6].fields.push(field)
    }
  })
  
  return groups.filter(group => group.fields.length > 0)
})

// 表单状态
const formState = reactive<Record<string, any>>({})

// 表单校验规则
const rules = computed(() => {
  const validationRules: Record<string, any[]> = {}
  fields.value.forEach(field => {
    if (field.required) {
      validationRules[field.name] = [{
        required: true,
        message: `请${field.fieldType === 'select' ? '选择' : '输入'}${field.label}`
      }]
    }
    if (field.validation?.length) {
      // 添加自定义验证规则
      field.validation.forEach(rule => {
        switch (rule) {
          case 'email':
            validationRules[field.name].push({
              type: 'email',
              message: '请输入正确的邮箱格式'
            })
            break
          case 'phone':
            validationRules[field.name].push({
              pattern: /^1[3-9]\d{9}$/,
              message: '请输入正确的手机号码'
            })
            break
          // ... 其他验证规则
        }
      })
    }
  })
  return validationRules
})

// 获取土地列表
const fetchLandList = async () => {
  loading.value = true
  try {
    // TODO: 调用后端API获取土地列表
    await new Promise(resolve => setTimeout(resolve, 1000))
  } catch (error) {
    message.error('获取土地列表失败')
  }
  loading.value = false
}

// 显示新增弹窗
const showCreateModal = async () => {
  try {
    // 模拟获取字段定义
    await new Promise(resolve => setTimeout(resolve, 500))
    fields.value = [
      // 基本信息
      {
        name: 'companyName',
        label: '企业名称',
        fieldType: 'text',
        required: true,
        sort: 1
      },
      {
        name: 'companyCode',
        label: '企业编码',
        fieldType: 'text',
        required: true,
        sort: 2
      },
      {
        name: 'assetCode',
        label: '资产编码',
        fieldType: 'text',
        required: true,
        sort: 3
      },
      {
        name: 'landName',
        label: '宗地名称',
        fieldType: 'text',
        required: true,
        sort: 4
      },
      // 位置信息
      {
        name: 'province',
        label: '省（自治区、直辖市）',
        fieldType: 'select',
        required: true,
        options: ['浙江省', '江苏省', '上海市'],
        sort: 5
      },
      {
        name: 'city',
        label: '市（地、州、盟）',
        fieldType: 'select',
        required: true,
        options: ['杭州市', '宁波市', '温州市'],
        sort: 6
      },
      {
        name: 'district',
        label: '区/县',
        fieldType: 'select',
        required: true,
        options: ['西湖区', '滨江区', '余杭区'],
        sort: 7
      },
      {
        name: 'address',
        label: '具体位置',
        fieldType: 'text',
        required: true,
        sort: 8
      },
      {
        name: 'coordinates',
        label: '经纬度',
        fieldType: 'text',
        required: true,
        sort: 9
      },
      // 土地信息
      {
        name: 'acquisitionDate',
        label: '土地取得时间',
        fieldType: 'date',
        required: true,
        sort: 10
      },
      {
        name: 'plannedUsage',
        label: '规划用途',
        fieldType: 'select',
        required: true,
        options: ['商业用地', '工业用地', '住宅用地', '办公用地'],
        sort: 11
      },
      {
        name: 'landNature',
        label: '土地性质',
        fieldType: 'select',
        required: true,
        options: ['国有', '集体'],
        sort: 12
      },
      {
        name: 'rightType',
        label: '土地使用权类型',
        fieldType: 'select',
        options: ['出让', '划拨', '租赁'],
        sort: 13
      },
      {
        name: 'acquisitionPrice',
        label: '取得价格（元）',
        fieldType: 'number',
        sort: 14
      },
      // 面积信息
      {
        name: 'totalArea',
        label: '土地面积（平方米）',
        fieldType: 'number',
        required: true,
        sort: 15
      },
      {
        name: 'usedArea',
        label: '已使用面积（平方米）',
        fieldType: 'number',
        required: true,
        sort: 16
      },
      {
        name: 'idleArea',
        label: '闲置面积（平方米）',
        fieldType: 'number',
        sort: 17
      },
      // 权证信息
      {
        name: 'hasCertificate',
        label: '是否有证',
        fieldType: 'select',
        required: true,
        options: ['是', '否'],
        sort: 18
      },
      {
        name: 'landOwner',
        label: '土地所有权人',
        fieldType: 'text',
        sort: 19
      },
      {
        name: 'certificateNumber',
        label: '权证编号',
        fieldType: 'text',
        sort: 20
      },
      // 其他信息
      {
        name: 'buildingCount',
        label: '附着建筑物数量',
        fieldType: 'number',
        sort: 21
      },
      {
        name: 'remarks',
        label: '备注',
        fieldType: 'textarea',
        sort: 22
      }
    ]
    
    // 初始化表单状态
    const newFormState: Record<string, any> = {}
    fields.value.forEach(field => {
      newFormState[field.name] = undefined
    })
    Object.assign(formState, newFormState)
    
    isEdit.value = false
    modalVisible.value = true
  } catch (error) {
    message.error('获取字段定义失败')
  }
}

// 显示编辑弹窗
const showEditModal = (record: any) => {
  modalTitle.value = '编辑土地'
  isEdit.value = true
  Object.assign(formState, record)
  modalVisible.value = true
}

// 显示详情
const showDetailModal = (record: any) => {
  // TODO: 实现详情查看功能
  console.log('查看详情:', record)
}

// 显示历史记录
const showHistoryModal = (record: any) => {
  // TODO: 实现历史记录查看功能
  console.log('查看历史记录:', record)
}

// 处理删除
const handleDelete = async (record: any) => {
  try {
    // TODO: 调用后端API删除土地
    await new Promise(resolve => setTimeout(resolve, 1000))
    message.success('删除成功')
    fetchLandList()
  } catch (error) {
    message.error('删除失败')
  }
}

// 处理表格变化
const handleTableChange = (pag: any) => {
  pagination.current = pag.current
  pagination.pageSize = pag.pageSize
  fetchLandList()
}

// 弹窗确认
const handleModalOk = () => {
  formRef.value?.validate().then(async () => {
    try {
      // TODO: 调用后端API保存土地信息
      await new Promise(resolve => setTimeout(resolve, 1000))
      message.success(isEdit.value ? '更新成功' : '添加成功')
      modalVisible.value = false
      fetchLandList()
    } catch (error) {
      message.error(isEdit.value ? '更新失败' : '添加失败')
    }
  })
}

// 弹窗取消
const handleModalCancel = () => {
  modalVisible.value = false
  formRef.value?.resetFields()
}

// 获取状态样式
const getStatusClass = (status: string) => {
  const map: Record<string, string> = {
    '闲置': 'status-idle',
    '使用中': 'status-inuse',
    '已预留': 'status-reserved'
  }
  return map[status]
}

// 高级搜索相关
const searchDrawerVisible = ref(false)
const advancedSearch = reactive({
  status: [],
  purpose: [],
  minArea: undefined,
  maxArea: undefined,
  department: []
})

// 部门数据
const departments = [
  { id: 1, name: '资产管理部' },
  { id: 2, name: '行政部' },
  { id: 3, name: '财务部' }
]

// 区域选项
const regionOptions = [
  {
    value: 'zhejiang',
    label: '浙江省',
    children: [
      {
        value: 'hangzhou',
        label: '杭州市',
        children: [
          {
            value: 'xihu',
            label: '西湖区'
          }
        ]
      }
    ]
  }
]

// 显示高级搜索
const showAdvancedSearch = () => {
  searchDrawerVisible.value = true
}

// 重置高级搜索
const resetAdvancedSearch = () => {
  Object.assign(advancedSearch, {
    status: [],
    purpose: [],
    minArea: undefined,
    maxArea: undefined,
    department: []
  })
}

// 处理高级搜索
const handleAdvancedSearch = () => {
  console.log('高级搜索条件:', advancedSearch)
  searchDrawerVisible.value = false
  fetchLandList()
}

// 初始化
fetchLandList()
</script>

<style lang="scss" scoped>
.land-list {
  .page-header {
    margin-bottom: $spacing-md;
    
    h2 {
      margin: 0;
      font-size: 24px;
      color: $text-primary;
    }
  }

  .header-actions {
    margin-bottom: $spacing-lg;
    display: flex;
    justify-content: space-between;
    align-items: center;
  }

  .custom-button {
    background: $primary-color;
    border-color: $primary-color;
    border-radius: $border-radius-md;
    
    &:hover {
      background: darken($primary-color, 5%);
      border-color: darken($primary-color, 5%);
    }
  }

  .custom-search {
    width: 300px;
    
    :deep(.ant-input) {
      border-radius: $border-radius-md;
    }
    
    :deep(.ant-input-search-button) {
      border-radius: 0 $border-radius-md $border-radius-md 0;
    }
  }

  .custom-card {
    border-radius: $border-radius-lg;
    box-shadow: $shadow-sm;
  }

  .status-tag {
    border-radius: $border-radius-sm;
    padding: 4px 12px;
    
    &.status-idle {
      background: rgba($warning-color, 0.1);
      color: darken($warning-color, 20%);
      border-color: $warning-color;
    }
    
    &.status-inuse {
      background: rgba($success-color, 0.1);
      color: darken($success-color, 20%);
      border-color: $success-color;
    }
    
    &.status-reserved {
      background: rgba($primary-color, 0.1);
      color: darken($primary-color, 20%);
      border-color: $primary-color;
    }
  }

  .action-link {
    color: $primary-color;
    
    &:hover {
      color: darken($primary-color, 10%);
    }
  }

  .drawer-footer {
    position: absolute;
    bottom: 0;
    width: 100%;
    border-top: 1px solid $border-color;
    padding: $spacing-md;
    text-align: right;
    left: 0;
    background: white;
  }

  .custom-table {
    :deep(.ant-table-thead > tr > th) {
      background: $background-light;
      color: $text-primary;
    }
    
    :deep(.ant-table-tbody > tr > td) {
      color: $text-secondary;
    }
  }
}
</style> 