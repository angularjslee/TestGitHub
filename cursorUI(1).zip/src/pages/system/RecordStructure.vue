<template>
  <div class="record-structure">
    <div class="page-header">
      <h2>记录结构管理</h2>
    </div>

    <div class="header-actions">
      <a-space>
        <a-select
          v-model:value="currentType"
          class="type-selector"
          @change="handleTypeChange"
        >
          <a-select-option value="land">土地资源</a-select-option>
          <a-select-option value="property">房产</a-select-option>
        </a-select>
        <a-button type="primary" @click="showAddFieldModal" class="custom-button">
          <template #icon><PlusOutlined /></template>
          添加字段
        </a-button>
      </a-space>
    </div>

    <a-card class="custom-card">
      <a-table
        :columns="columns"
        :data-source="fieldList"
        :loading="loading"
        class="custom-table"
      >
        <!-- 字段类型列 -->
        <template #fieldType="{ text }">
          <a-tag>{{ getFieldTypeName(text) }}</a-tag>
        </template>

        <!-- 是否必填列 -->
        <template #required="{ text }">
          <a-tag :color="text ? 'red' : ''">
            {{ text ? '必填' : '选填' }}
          </a-tag>
        </template>

        <!-- 操作列 -->
        <template #action="{ record }">
          <a-space>
            <a class="action-link" @click="showEditFieldModal(record)">编辑</a>
            <a-divider type="vertical" />
            <a-popconfirm
              title="确定要删除该字段吗？"
              @confirm="handleDeleteField(record)"
            >
              <a class="action-link">删除</a>
            </a-popconfirm>
          </a-space>
        </template>
      </a-table>
    </a-card>

    <!-- 添加/编辑字段弹窗 -->
    <a-modal
      v-model:visible="modalVisible"
      :title="modalTitle"
      @ok="handleModalOk"
      @cancel="handleModalCancel"
    >
      <a-form
        ref="formRef"
        :model="formState"
        :rules="rules"
        :label-col="{ span: 6 }"
        :wrapper-col="{ span: 16 }"
      >
        <a-form-item label="字段名称" name="name">
          <a-input v-model:value="formState.name" :disabled="isEdit" />
        </a-form-item>

        <a-form-item label="显示名称" name="label">
          <a-input v-model:value="formState.label" />
        </a-form-item>

        <a-form-item label="字段类型" name="fieldType">
          <a-select v-model:value="formState.fieldType">
            <a-select-option value="text">文本</a-select-option>
            <a-select-option value="number">数字</a-select-option>
            <a-select-option value="select">下拉选择</a-select-option>
            <a-select-option value="date">日期</a-select-option>
            <a-select-option value="textarea">多行文本</a-select-option>
            <a-select-option value="cascader">级联选择</a-select-option>
            <a-select-option value="upload">文件上传</a-select-option>
          </a-select>
        </a-form-item>

        <a-form-item label="是否必填" name="required">
          <a-switch v-model:checked="formState.required" />
        </a-form-item>

        <template v-if="formState.fieldType === 'select'">
          <a-form-item label="选项列表" name="options">
            <a-space direction="vertical" style="width: 100%">
              <a-input
                v-for="(option, index) in formState.options"
                :key="index"
                v-model:value="formState.options[index]"
                placeholder="请输入选项"
              >
                <template #suffix>
                  <MinusCircleOutlined
                    v-if="formState.options.length > 1"
                    @click="removeOption(index)"
                  />
                </template>
              </a-input>
              <a-button type="dashed" block @click="addOption">
                <PlusOutlined />添加选项
              </a-button>
            </a-space>
          </a-form-item>
        </template>

        <a-form-item label="验证规则" name="validation">
          <a-select
            v-model:value="formState.validation"
            mode="multiple"
            placeholder="请选择验证规则"
          >
            <a-select-option value="email">邮箱格式</a-select-option>
            <a-select-option value="phone">手机号码</a-select-option>
            <a-select-option value="url">URL地址</a-select-option>
          </a-select>
        </a-form-item>

        <a-form-item label="排序号" name="sort">
          <a-input-number v-model:value="formState.sort" :min="0" style="width: 100%" />
        </a-form-item>

        <a-form-item label="字段说明" name="description">
          <a-textarea v-model:value="formState.description" :rows="3" />
        </a-form-item>
      </a-form>
    </a-modal>
  </div>
</template>

<script lang="ts" setup>
import { ref, reactive, computed } from 'vue'
import { message } from 'ant-design-vue'
import {
  PlusOutlined,
  MinusCircleOutlined
} from '@ant-design/icons-vue'
import type { TableColumnsType } from 'ant-design-vue'

// 当前选中的记录类型
const currentType = ref('land')

// 表格列定义
const columns: TableColumnsType = [
  {
    title: '字段名称',
    dataIndex: 'name',
    key: 'name',
  },
  {
    title: '显示名称',
    dataIndex: 'label',
    key: 'label',
  },
  {
    title: '字段类型',
    dataIndex: 'fieldType',
    key: 'fieldType',
    slots: { customRender: 'fieldType' }
  },
  {
    title: '是否必填',
    dataIndex: 'required',
    key: 'required',
    slots: { customRender: 'required' }
  },
  {
    title: '排序号',
    dataIndex: 'sort',
    key: 'sort',
  },
  {
    title: '操作',
    key: 'action',
    slots: { customRender: 'action' }
  }
]

// 字段类型名称映射
const fieldTypeNames: Record<string, string> = {
  text: '文本',
  number: '数字',
  select: '下拉选择',
  date: '日期',
  textarea: '多行文本',
  cascader: '级联选择',
  upload: '文件上传'
}

const getFieldTypeName = (type: string) => fieldTypeNames[type] || type

// 表单状态
const formState = reactive({
  name: '',
  label: '',
  fieldType: 'text',
  required: false,
  options: [''],
  validation: [],
  sort: 0,
  description: ''
})

// 表单校验规则
const rules = {
  name: [
    { required: true, message: '请输入字段名称' },
    { pattern: /^[a-zA-Z][a-zA-Z0-9_]*$/, message: '字段名称只能包含字母、数字和下划线，且必须以字母开头' }
  ],
  label: [{ required: true, message: '请输入显示名称' }],
  fieldType: [{ required: true, message: '请选择字段类型' }],
  sort: [{ required: true, message: '请输入排序号' }]
}

// 添加选项
const addOption = () => {
  formState.options.push('')
}

// 删除选项
const removeOption = (index: number) => {
  formState.options.splice(index, 1)
}

// 处理记录类型切换
const handleTypeChange = (value: string) => {
  currentType.value = value
  fetchFieldList()
}

// 获取字段列表
const loading = ref(false)
const fieldList = ref([])

// 弹窗相关
const modalVisible = ref(false)
const modalTitle = computed(() => isEdit.value ? '编辑字段' : '添加字段')
const isEdit = ref(false)
const formRef = ref()

// 显示添加字段弹窗
const showAddFieldModal = () => {
  isEdit.value = false
  formState.name = ''
  formState.label = ''
  formState.fieldType = 'text'
  formState.required = false
  formState.options = ['']
  formState.validation = []
  formState.sort = fieldList.value.length + 1
  formState.description = ''
  modalVisible.value = true
}

// 显示编辑字段弹窗
const showEditFieldModal = (record: any) => {
  isEdit.value = true
  Object.assign(formState, {
    ...record,
    options: record.options || [''],
    validation: record.validation || []
  })
  modalVisible.value = true
}

// 处理删除字段
const handleDeleteField = async (record: any) => {
  try {
    // TODO: 调用后端API删除字段
    await new Promise(resolve => setTimeout(resolve, 1000))
    message.success('删除成功')
    fetchFieldList()
  } catch (error) {
    message.error('删除失败')
  }
}

// 处理弹窗确认
const handleModalOk = () => {
  formRef.value?.validate().then(async () => {
    try {
      // TODO: 调用后端API保存字段
      await new Promise(resolve => setTimeout(resolve, 1000))
      modalVisible.value = false
      message.success(isEdit.value ? '更新成功' : '添加成功')
      fetchFieldList()
    } catch (error) {
      message.error(isEdit.value ? '更新失败' : '添加失败')
    }
  })
}

// 处理弹窗取消
const handleModalCancel = () => {
  modalVisible.value = false
  formRef.value?.resetFields()
}

// 修改 fetchFieldList 函数，根据当前类型返回不同的默认字段
const fetchFieldList = async () => {
  loading.value = true
  try {
    if (currentType.value === 'land') {
      fieldList.value = [
        // 基本信息
        {
          name: 'code',
          label: '资产编码',
          fieldType: 'text',
          required: true,
          sort: 1
        },
        {
          name: 'companyName',
          label: '企业名称',
          fieldType: 'text',
          required: true,
          sort: 2
        },
        {
          name: 'companyCode',
          label: '企业编码',
          fieldType: 'text',
          required: true,
          sort: 3
        },
        {
          name: 'landName',
          label: '宗地名称',
          fieldType: 'text',
          required: true,
          sort: 4
        },
        // 位置信息
        {
          name: 'province',
          label: '省（自治区、直辖市）',
          fieldType: 'select',
          required: true,
          sort: 5
        },
        {
          name: 'city',
          label: '市（地、州、盟）',
          fieldType: 'select',
          required: true,
          sort: 6
        },
        {
          name: 'district',
          label: '区/县',
          fieldType: 'select',
          required: true,
          sort: 7
        },
        {
          name: 'address',
          label: '具体位置',
          fieldType: 'text',
          required: true,
          sort: 8
        },
        {
          name: 'coordinates',
          label: '经纬度',
          fieldType: 'text',
          required: true,
          sort: 9
        },
        // 土地信息
        {
          name: 'acquisitionDate',
          label: '土地取得时间',
          fieldType: 'date',
          required: true,
          sort: 10
        },
        {
          name: 'plannedUsage',
          label: '规划用途',
          fieldType: 'select',
          required: true,
          options: ['商业用地', '工业用地', '住宅用地', '办公用地'],
          sort: 11
        },
        {
          name: 'landNature',
          label: '土地性质',
          fieldType: 'select',
          required: true,
          options: ['国有', '集体'],
          sort: 12
        },
        {
          name: 'rightType',
          label: '土地使用权类型',
          fieldType: 'select',
          options: ['出让', '划拨', '租赁'],
          sort: 13
        },
        {
          name: 'acquisitionPrice',
          label: '取得价格（元）',
          fieldType: 'number',
          sort: 14
        },
        // 面积信息
        {
          name: 'totalArea',
          label: '土地面积（平方米）',
          fieldType: 'number',
          required: true,
          sort: 15
        },
        {
          name: 'usedArea',
          label: '已使用面积（平方米）',
          fieldType: 'number',
          required: true,
          sort: 16
        },
        {
          name: 'idleArea',
          label: '闲置面积（平方米）',
          fieldType: 'number',
          sort: 17
        },
        // 权证信息
        {
          name: 'hasCertificate',
          label: '是否有证',
          fieldType: 'select',
          required: true,
          options: ['是', '否'],
          sort: 18
        },
        {
          name: 'landOwner',
          label: '土地所有权人',
          fieldType: 'text',
          sort: 19
        },
        {
          name: 'certificateNumber',
          label: '权证编号',
          fieldType: 'text',
          sort: 20
        },
        // 资产信息
        {
          name: 'originalValue',
          label: '资产原值(元）',
          fieldType: 'number',
          sort: 21
        },
        {
          name: 'netValue',
          label: '资产净值（元）',
          fieldType: 'number',
          sort: 22
        },
        {
          name: 'usage',
          label: '资产用途',
          fieldType: 'text',
          sort: 23
        },
        // 其他信息
        {
          name: 'buildingCount',
          label: '附着建筑物数量',
          fieldType: 'number',
          sort: 24
        },
        {
          name: 'accountingSubject',
          label: '核算科目',
          fieldType: 'text',
          sort: 25
        },
        {
          name: 'isNewThisYear',
          label: '是否为本年新增',
          fieldType: 'select',
          options: ['是', '否'],
          sort: 26
        },
        {
          name: 'remarks',
          label: '备注',
          fieldType: 'textarea',
          sort: 27
        }
      ]
    } else {
      fieldList.value = [
        {
          name: 'code',
          label: '房产编号',
          fieldType: 'text',
          required: true,
          sort: 1
        },
        {
          name: 'address',
          label: '地址',
          fieldType: 'text',
          required: true,
          sort: 2
        },
        {
          name: 'area',
          label: '建筑面积',
          fieldType: 'number',
          required: true,
          sort: 3
        },
        {
          name: 'status',
          label: '使用状态',
          fieldType: 'select',
          required: true,
          options: ['闲置', '使用中', '维修中'],
          sort: 4
        }
      ]
    }
  } catch (error) {
    message.error('获取字段列表失败')
  }
  loading.value = false
}

// 初始化
fetchFieldList()
</script>

<style lang="scss" scoped>
.record-structure {
  .page-header {
    margin-bottom: $spacing-md;
    
    h2 {
      margin: 0;
      font-size: 24px;
      color: $text-primary;
    }
  }

  .header-actions {
    margin-bottom: $spacing-lg;
    display: flex;
    justify-content: space-between;
    align-items: center;
  }

  .type-selector {
    width: 200px;
  }

  .custom-button {
    background: $primary-color;
    border-color: $primary-color;
    border-radius: $border-radius-md;
    
    &:hover {
      background: darken($primary-color, 5%);
      border-color: darken($primary-color, 5%);
    }
  }

  .custom-card {
    border-radius: $border-radius-lg;
    box-shadow: $shadow-sm;
  }

  .custom-table {
    :deep(.ant-table-thead > tr > th) {
      background: $background-light;
      color: $text-primary;
    }
    
    :deep(.ant-table-tbody > tr > td) {
      color: $text-secondary;
    }
  }

  .action-link {
    color: $primary-color;
    
    &:hover {
      color: darken($primary-color, 10%);
    }
  }

  // 添加弹窗样式
  :deep(.ant-modal-content) {
    border-radius: $border-radius-lg;
  }
  
  :deep(.ant-form-item) {
    margin-bottom: $spacing-lg;
  }
  
  :deep(.ant-select) {
    width: 100%;
  }
  
  :deep(.ant-input-number) {
    width: 100%;
  }
}
</style> 