<template>
  <div class="permission-list">
    <div class="page-header">
      <h2>权限管理</h2>
      <div class="header-actions">
        <a-button type="primary" @click="showCreateModal" class="custom-button">
          <template #icon><PlusOutlined /></template>
          新建权限
        </a-button>
      </div>
    </div>

    <a-card class="custom-card">
      <a-table
        :columns="columns"
        :data-source="permissionList"
        :loading="loading"
        class="custom-table"
      >
        <!-- 操作列 -->
        <template #action="{ record }">
          <a-space>
            <a class="action-link" @click="showEditModal(record)">编辑</a>
            <a-divider type="vertical" />
            <a-popconfirm
              title="确定要删除该权限吗？"
              @confirm="handleDelete(record)"
            >
              <a class="action-link">删除</a>
            </a-popconfirm>
          </a-space>
        </template>
      </a-table>
    </a-card>

    <!-- 创建/编辑权限弹窗 -->
    <a-modal
      v-model:visible="modalVisible"
      :title="modalTitle"
      @ok="handleModalOk"
      @cancel="handleModalCancel"
      class="custom-modal"
    >
      <a-form
        ref="formRef"
        :model="formState"
        :rules="rules"
        :label-col="{ span: 6 }"
        :wrapper-col="{ span: 16 }"
        class="custom-form"
      >
        <a-form-item label="权限名称" name="name">
          <a-input v-model:value="formState.name" />
        </a-form-item>
        <a-form-item label="权限标识" name="key">
          <a-input v-model:value="formState.key" :disabled="isEdit" />
        </a-form-item>
        <a-form-item label="上级权限" name="parentId">
          <a-tree-select
            v-model:value="formState.parentId"
            :tree-data="permissionTreeData"
            placeholder="请选择上级权限"
            allow-clear
            tree-default-expand-all
          />
        </a-form-item>
        <a-form-item label="描述" name="description">
          <a-textarea v-model:value="formState.description" :rows="4" />
        </a-form-item>
      </a-form>
    </a-modal>
  </div>
</template>

<script lang="ts" setup>
import { ref, reactive } from 'vue'
import { PlusOutlined } from '@ant-design/icons-vue'
import type { TableColumnsType } from 'ant-design-vue'
import { message } from 'ant-design-vue'

interface Permission {
  id: string
  name: string
  key: string
  parentId?: string
  description: string
  createTime: string
}

interface PermissionForm {
  name: string
  key: string
  parentId?: string
  description: string
}

// 表格列定义
const columns: TableColumnsType<Permission> = [
  {
    title: '权限名称',
    dataIndex: 'name',
    key: 'name',
  },
  {
    title: '权限标识',
    dataIndex: 'key',
    key: 'key',
  },
  {
    title: '描述',
    dataIndex: 'description',
    key: 'description',
  },
  {
    title: '创建时间',
    dataIndex: 'createTime',
    key: 'createTime',
  },
  {
    title: '操作',
    key: 'action',
    slots: { customRender: 'action' }
  }
]

// 表格数据
const loading = ref(false)
const permissionList = ref<Permission[]>([])

// 获取权限列表
const fetchPermissionList = async () => {
  loading.value = true
  try {
    // TODO: 调用后端API获取权限列表
    permissionList.value = [
      {
        id: '1',
        name: '组织架构',
        key: 'system',
        description: '组织架构相关权限',
        createTime: '2024-03-22 12:00:00'
      },
      {
        id: '2',
        name: '用户管理',
        key: 'system:user',
        parentId: '1',
        description: '用户管理相关权限',
        createTime: '2024-03-22 12:00:00'
      }
    ]
  } catch (error) {
    message.error('获取权限列表失败')
  }
  loading.value = false
}

// 权限树数据
const permissionTreeData = ref([
  {
    title: '组织架构',
    value: '1',
    children: [
      {
        title: '用户管理',
        value: '2'
      }
    ]
  }
])

// 表单相关
const formRef = ref()
const modalVisible = ref(false)
const modalTitle = ref('新建权限')
const isEdit = ref(false)

const formState = reactive<PermissionForm>({
  name: '',
  key: '',
  parentId: undefined,
  description: ''
})

const rules = {
  name: [
    { required: true, message: '请输入权限名称' },
    { min: 2, message: '权限名称至少2个字符' }
  ],
  key: [
    { required: true, message: '请输入权限标识' },
    { pattern: /^[a-z][a-z:]*[a-z]$/, message: '权限标识只能包含小写字母和冒号' }
  ],
  description: [
    { max: 200, message: '描述最多200个字符' }
  ]
}

// 显示创建权限弹窗
const showCreateModal = () => {
  modalTitle.value = '新建权限'
  isEdit.value = false
  Object.assign(formState, {
    name: '',
    key: '',
    parentId: undefined,
    description: ''
  })
  modalVisible.value = true
}

// 显示编辑权限弹窗
const showEditModal = (record: Permission) => {
  modalTitle.value = '编辑权限'
  isEdit.value = true
  Object.assign(formState, {
    name: record.name,
    key: record.key,
    parentId: record.parentId,
    description: record.description
  })
  modalVisible.value = true
}

// 弹窗确认
const handleModalOk = () => {
  formRef.value.validate().then(() => {
    // TODO: 调用后端API保存权限信息
    message.success(isEdit.value ? '编辑成功' : '创建成功')
    modalVisible.value = false
    fetchPermissionList()
  })
}

// 弹窗取消
const handleModalCancel = () => {
  modalVisible.value = false
  formRef.value.resetFields()
}

// 删除权限
const handleDelete = async (record: Permission) => {
  try {
    // TODO: 调用后端API删除权限
    message.success('删除成功')
    fetchPermissionList()
  } catch (error) {
    message.error('删除失败')
  }
}

// 初始化
fetchPermissionList()
</script>

<style lang="scss" scoped>
.permission-list {
  .page-header {
    margin-bottom: $spacing-lg;
    
    h2 {
      color: $text-primary;
      margin-bottom: $spacing-md;
      font-size: 24px;
    }
  }

  .header-actions {
    margin-bottom: $spacing-md;
  }

  .custom-button {
    background: $primary-color;
    border-color: $primary-color;
    border-radius: $border-radius-md;
    
    &:hover {
      background: darken($primary-color, 5%);
      border-color: darken($primary-color, 5%);
    }
  }

  .custom-card {
    border-radius: $border-radius-lg;
    box-shadow: $shadow-sm;
  }

  .custom-table {
    :deep(.ant-table-thead > tr > th) {
      background: $background-light;
      color: $text-primary;
    }
    
    :deep(.ant-table-tbody > tr > td) {
      color: $text-secondary;
    }
  }

  .action-link {
    color: $primary-color;
    
    &:hover {
      color: darken($primary-color, 10%);
    }
  }

  .custom-modal {
    :deep(.ant-modal-content) {
      border-radius: $border-radius-lg;
    }
    
    :deep(.ant-modal-header) {
      border-radius: $border-radius-lg $border-radius-lg 0 0;
    }
  }

  .custom-form {
    :deep(.ant-form-item-label > label) {
      color: $text-primary;
    }
    
    :deep(.ant-input) {
      border-radius: $border-radius-md;
      
      &:focus {
        border-color: $primary-color;
        box-shadow: 0 0 0 2px rgba($primary-color, 0.2);
      }
    }
  }
}
</style> 