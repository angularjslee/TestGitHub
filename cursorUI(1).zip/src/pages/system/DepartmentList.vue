<template>
  <div class="department-list">
    <div class="page-header">
      <h2>部门管理</h2>
      <div class="header-actions">
        <a-button type="primary" @click="showAddModal">
          <template #icon><PlusOutlined /></template>
          新增部门
        </a-button>
      </div>
    </div>

    <!-- 部门表格 -->
    <a-table
      :columns="columns"
      :data-source="departments"
      :loading="loading"
      :pagination="pagination"
      @change="handleTableChange"
    >
      <template #bodyCell="{ column, record }">
        <template v-if="column.key === 'action'">
          <a-space>
            <a-button type="link" @click="handleEdit(record)">
              <template #icon><EditOutlined /></template>
              编辑
            </a-button>
            <a-button type="link" danger @click="handleDelete(record)">
              <template #icon><DeleteOutlined /></template>
              删除
            </a-button>
          </a-space>
        </template>
      </template>
    </a-table>

    <!-- 新增/编辑部门弹窗 -->
    <a-modal
      v-model:visible="modalVisible"
      :title="modalTitle"
      @ok="handleModalOk"
      @cancel="handleModalCancel"
    >
      <a-form
        ref="formRef"
        :model="formState"
        :rules="rules"
        :label-col="{ span: 6 }"
        :wrapper-col="{ span: 16 }"
      >
        <a-form-item label="部门名称" name="name">
          <a-input v-model:value="formState.name" placeholder="请输入部门名称" />
        </a-form-item>
        <a-form-item label="部门编码" name="code">
          <a-input v-model:value="formState.code" placeholder="请输入部门编码" />
        </a-form-item>
        <a-form-item label="上级部门" name="parentId">
          <a-tree-select
            v-model:value="formState.parentId"
            :tree-data="departmentTree"
            placeholder="请选择上级部门"
            allow-clear
            tree-default-expand-all
          />
        </a-form-item>
        <a-form-item label="部门描述" name="description">
          <a-textarea
            v-model:value="formState.description"
            placeholder="请输入部门描述"
            :rows="4"
          />
        </a-form-item>
        <a-form-item label="排序" name="sort">
          <a-input-number
            v-model:value="formState.sort"
            placeholder="请输入排序号"
            :min="0"
            :max="999"
          />
        </a-form-item>
      </a-form>
    </a-modal>
  </div>
</template>

<script lang="ts" setup>
import { ref, reactive } from 'vue'
import { message } from 'ant-design-vue'
import type { FormInstance } from 'ant-design-vue'
import {
  PlusOutlined,
  EditOutlined,
  DeleteOutlined
} from '@ant-design/icons-vue'

// 表格列定义
const columns = [
  {
    title: '部门名称',
    dataIndex: 'name',
    key: 'name',
    width: '20%'
  },
  {
    title: '部门编码',
    dataIndex: 'code',
    key: 'code',
    width: '15%'
  },
  {
    title: '上级部门',
    dataIndex: 'parentName',
    key: 'parentName',
    width: '15%'
  },
  {
    title: '排序',
    dataIndex: 'sort',
    key: 'sort',
    width: '10%'
  },
  {
    title: '描述',
    dataIndex: 'description',
    key: 'description',
    width: '25%'
  },
  {
    title: '操作',
    key: 'action',
    width: '15%'
  }
]

// 模拟数据
const departments = ref([
  {
    id: 1,
    name: '技术部',
    code: 'TECH',
    parentId: null,
    parentName: '-',
    sort: 1,
    description: '负责公司技术研发工作'
  },
  {
    id: 2,
    name: '研发一组',
    code: 'DEV1',
    parentId: 1,
    parentName: '技术部',
    sort: 1,
    description: '前端开发团队'
  }
])

const loading = ref(false)
const modalVisible = ref(false)
const modalTitle = ref('新增部门')
const formRef = ref<FormInstance>()

// 表单状态
const formState = reactive({
  id: undefined,
  name: '',
  code: '',
  parentId: undefined,
  description: '',
  sort: 0
})

// 表单校验规则
const rules = {
  name: [{ required: true, message: '请输入部门名称', trigger: 'blur' }],
  code: [{ required: true, message: '请输入部门编码', trigger: 'blur' }],
  sort: [{ required: true, message: '请输入排序号', trigger: 'blur' }]
}

// 分页配置
const pagination = reactive({
  current: 1,
  pageSize: 10,
  total: 0,
  showSizeChanger: true,
  showQuickJumper: true
})

// 部门树形数据
const departmentTree = ref([
  {
    title: '技术部',
    value: 1,
    children: [
      {
        title: '研发一组',
        value: 2
      }
    ]
  }
])

// 显示新增弹窗
const showAddModal = () => {
  modalTitle.value = '新增部门'
  formState.id = undefined
  formState.name = ''
  formState.code = ''
  formState.parentId = undefined
  formState.description = ''
  formState.sort = 0
  modalVisible.value = true
}

// 处理编辑
const handleEdit = (record: any) => {
  modalTitle.value = '编辑部门'
  Object.assign(formState, record)
  modalVisible.value = true
}

// 处理删除
const handleDelete = async (record: any) => {
  try {
    await new Promise((resolve) => setTimeout(resolve, 1000))
    message.success('删除成功')
  } catch (error) {
    message.error('删除失败')
  }
}

// 处理表格变化
const handleTableChange = (pag: any) => {
  pagination.current = pag.current
  pagination.pageSize = pag.pageSize
  // TODO: 加载数据
}

// 处理弹窗确认
const handleModalOk = () => {
  formRef.value?.validate().then(async () => {
    try {
      await new Promise((resolve) => setTimeout(resolve, 1000))
      modalVisible.value = false
      message.success(formState.id ? '更新成功' : '添加成功')
    } catch (error) {
      message.error(formState.id ? '更新失败' : '添加失败')
    }
  })
}

// 处理弹窗取消
const handleModalCancel = () => {
  modalVisible.value = false
  formRef.value?.resetFields()
}
</script>

<style lang="scss" scoped>
.department-list {
  .page-header {
    margin-bottom: $spacing-lg;
    display: flex;
    justify-content: space-between;
    align-items: center;
    
    h2 {
      margin: 0;
      font-size: 24px;
      color: $text-primary;
    }
  }
}
</style> 