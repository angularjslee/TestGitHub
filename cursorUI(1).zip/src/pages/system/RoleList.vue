<template>
  <div class="role-list">
    <div class="page-header">
      <h2>角色管理</h2>
      <div class="header-actions">
        <a-button type="primary" @click="showCreateModal" class="custom-button">
          <template #icon><PlusOutlined /></template>
          新建角色
        </a-button>
      </div>
    </div>

    <a-card class="custom-card">
      <a-table
        :columns="columns"
        :data-source="roleList"
        :loading="loading"
        class="custom-table"
      >
        <!-- 状态列 -->
        <template #status="{ text }">
          <a-tag :class="['status-tag', text ? 'status-active' : 'status-inactive']">
            {{ text ? '启用' : '禁用' }}
          </a-tag>
        </template>

        <!-- 操作列 -->
        <template #action="{ record }">
          <a-space>
            <a class="action-link" @click="showEditModal(record)">编辑</a>
            <a-divider type="vertical" />
            <a class="action-link" @click="showPermissionModal(record)">权限设置</a>
            <a-divider type="vertical" />
            <a-popconfirm
              :title="`确定要${record.status ? '禁用' : '启用'}该角色吗？`"
              @confirm="toggleRoleStatus(record)"
            >
              <a class="action-link">{{ record.status ? '禁用' : '启用' }}</a>
            </a-popconfirm>
          </a-space>
        </template>
      </a-table>
    </a-card>

    <!-- 创建/编辑角色弹窗 -->
    <a-modal
      v-model:visible="modalVisible"
      :title="modalTitle"
      @ok="handleModalOk"
      @cancel="handleModalCancel"
      class="custom-modal"
    >
      <a-form
        ref="formRef"
        :model="formState"
        :rules="rules"
        :label-col="{ span: 6 }"
        :wrapper-col="{ span: 16 }"
        class="custom-form"
      >
        <a-form-item label="角色名称" name="name">
          <a-input v-model:value="formState.name" />
        </a-form-item>
        <a-form-item label="角色编码" name="code">
          <a-input v-model:value="formState.code" :disabled="isEdit" />
        </a-form-item>
        <a-form-item label="描述" name="description">
          <a-textarea v-model:value="formState.description" :rows="4" />
        </a-form-item>
      </a-form>
    </a-modal>

    <!-- 权限设置弹窗 -->
    <a-modal
      v-model:visible="permissionModalVisible"
      title="权限设置"
      width="800px"
      @ok="handlePermissionModalOk"
      @cancel="handlePermissionModalCancel"
      class="custom-modal"
    >
      <a-tree
        v-model:checkedKeys="selectedPermissions"
        :tree-data="permissionTree"
        checkable
        :defaultExpandAll="true"
        class="custom-tree"
      />
    </a-modal>
  </div>
</template>

<script lang="ts" setup>
import { ref, reactive } from 'vue'
import { PlusOutlined } from '@ant-design/icons-vue'
import type { TableColumnsType } from 'ant-design-vue'
import { message } from 'ant-design-vue'
import type { Role, PermissionTreeNode, RoleFormState } from '@/types/system'

// 表格列定义
const columns: TableColumnsType<Role> = [
  {
    title: '角色名称',
    dataIndex: 'name',
    key: 'name',
  },
  {
    title: '角色编码',
    dataIndex: 'code',
    key: 'code',
  },
  {
    title: '描述',
    dataIndex: 'description',
    key: 'description',
  },
  {
    title: '状态',
    dataIndex: 'status',
    key: 'status',
    slots: { customRender: 'status' }
  },
  {
    title: '创建时间',
    dataIndex: 'createTime',
    key: 'createTime',
  },
  {
    title: '操作',
    key: 'action',
    slots: { customRender: 'action' }
  }
]

// 表格数据
const loading = ref(false)
const roleList = ref<Role[]>([])

// 获取角色列表
const fetchRoleList = async () => {
  loading.value = true
  try {
    // TODO: 调用后端API获取角色列表
    roleList.value = [
      {
        id: '1',
        name: '超级管理员',
        code: 'SUPER_ADMIN',
        description: '系统最高权限',
        status: true,
        createTime: '2024-03-22 12:00:00'
      },
      {
        id: '2',
        name: '普通管理员',
        code: 'ADMIN',
        description: '一般管理权限',
        status: true,
        createTime: '2024-03-22 12:00:00'
      }
    ]
  } catch (error) {
    message.error('获取角色列表失败')
  }
  loading.value = false
}

// 表单相关
const formRef = ref()
const modalVisible = ref(false)
const modalTitle = ref('新建角色')
const isEdit = ref(false)

const formState = reactive<RoleFormState>({
  name: '',
  code: '',
  description: ''
})

const rules = {
  name: [
    { required: true, message: '请输入角色名称' },
    { min: 2, message: '角色名称至少2个字符' }
  ],
  code: [
    { required: true, message: '请输入角色编码' },
    { pattern: /^[A-Z_]+$/, message: '角色编码只能包含大写字母和下划线' }
  ],
  description: [
    { max: 200, message: '描述最多200个字符' }
  ]
}

// 显示创建角色弹窗
const showCreateModal = () => {
  modalTitle.value = '新建角色'
  isEdit.value = false
  Object.assign(formState, {
    name: '',
    code: '',
    description: ''
  })
  modalVisible.value = true
}

// 显示编辑角色弹窗
const showEditModal = (record: Role) => {
  modalTitle.value = '编辑角色'
  isEdit.value = true
  Object.assign(formState, {
    name: record.name,
    code: record.code,
    description: record.description
  })
  modalVisible.value = true
}

// 弹窗确认
const handleModalOk = () => {
  formRef.value.validate().then(() => {
    // TODO: 调用后端API保存角色信息
    message.success(isEdit.value ? '编辑成功' : '创建成功')
    modalVisible.value = false
    fetchRoleList()
  })
}

// 弹窗取消
const handleModalCancel = () => {
  modalVisible.value = false
  formRef.value.resetFields()
}

// 权限相关
const permissionModalVisible = ref(false)
const selectedPermissions = ref<string[]>([])
const permissionTree = ref<PermissionTreeNode[]>([
  {
    title: '组织架构',
    key: 'system',
    children: [
      {
        title: '用户管理',
        key: 'system:user',
        children: [
          { title: '查看用户', key: 'system:user:view' },
          { title: '创建用户', key: 'system:user:create' },
          { title: '编辑用户', key: 'system:user:edit' },
          { title: '删除用户', key: 'system:user:delete' }
        ]
      },
      {
        title: '角色管理',
        key: 'system:role',
        children: [
          { title: '查看角色', key: 'system:role:view' },
          { title: '创建角色', key: 'system:role:create' },
          { title: '编辑角色', key: 'system:role:edit' },
          { title: '删除角色', key: 'system:role:delete' }
        ]
      }
    ]
  },
  {
    title: '房产管理',
    key: 'property',
    children: [
      {
        title: '房产信息',
        key: 'property:info',
        children: [
          { title: '查看房产', key: 'property:info:view' },
          { title: '添加房产', key: 'property:info:create' },
          { title: '编辑房产', key: 'property:info:edit' },
          { title: '删除房产', key: 'property:info:delete' }
        ]
      }
    ]
  }
])

// 显示权限设置弹窗
const showPermissionModal = (record: Role) => {
  console.log('当前角色:', record.name)
  // TODO: 获取角色当前权限
  selectedPermissions.value = ['system:user:view', 'system:user:create']
  permissionModalVisible.value = true
}

// 权限弹窗确认
const handlePermissionModalOk = () => {
  // TODO: 调用后端API保存角色权限
  message.success('权限设置成功')
  permissionModalVisible.value = false
}

// 权限弹窗取消
const handlePermissionModalCancel = () => {
  permissionModalVisible.value = false
}

// 切换角色状态
const toggleRoleStatus = async (record: Role) => {
  try {
    // TODO: 调用后端API修改角色状态
    message.success(record.status ? '已禁用' : '已启用')
    fetchRoleList()
  } catch (error) {
    message.error('操作失败')
  }
}

// 初始化
fetchRoleList()
</script>

<style lang="scss" scoped>
.role-list {
  .page-header {
    margin-bottom: $spacing-lg;
    
    h2 {
      color: $text-primary;
      margin-bottom: $spacing-md;
      font-size: 24px;
    }
  }

  .header-actions {
    margin-bottom: $spacing-md;
  }

  .custom-button {
    background: $primary-color;
    border-color: $primary-color;
    border-radius: $border-radius-md;
    
    &:hover {
      background: darken($primary-color, 5%);
      border-color: darken($primary-color, 5%);
    }
  }

  .custom-card {
    border-radius: $border-radius-lg;
    box-shadow: $shadow-sm;
  }

  .custom-table {
    :deep(.ant-table-thead > tr > th) {
      background: $background-light;
      color: $text-primary;
    }
    
    :deep(.ant-table-tbody > tr > td) {
      color: $text-secondary;
    }
  }

  .status-tag {
    border-radius: $border-radius-sm;
    padding: 4px 12px;
    
    &.status-active {
      background: rgba($success-color, 0.1);
      color: darken($success-color, 20%);
      border-color: $success-color;
    }
    
    &.status-inactive {
      background: rgba($error-color, 0.1);
      color: darken($error-color, 20%);
      border-color: $error-color;
    }
  }

  .action-link {
    color: $primary-color;
    
    &:hover {
      color: darken($primary-color, 10%);
    }
  }

  .custom-modal {
    :deep(.ant-modal-content) {
      border-radius: $border-radius-lg;
    }
    
    :deep(.ant-modal-header) {
      border-radius: $border-radius-lg $border-radius-lg 0 0;
    }
  }

  .custom-form {
    :deep(.ant-form-item-label > label) {
      color: $text-primary;
    }
    
    :deep(.ant-input) {
      border-radius: $border-radius-md;
      
      &:focus {
        border-color: $primary-color;
        box-shadow: 0 0 0 2px rgba($primary-color, 0.2);
      }
    }
  }

  .custom-tree {
    :deep(.ant-tree-treenode) {
      padding: 4px 0;
    }
    
    :deep(.ant-tree-node-content-wrapper:hover) {
      background-color: rgba($primary-color, 0.1);
    }
    
    :deep(.ant-tree-checkbox-checked .ant-tree-checkbox-inner) {
      background-color: $primary-color;
      border-color: $primary-color;
    }
  }
}
</style> 