<template>
  <div class="asset-import">
    <div class="page-header">
      <h2>资产导入</h2>
    </div>

    <a-tabs default-active-key="land" class="import-tabs">
      <a-tab-pane key="land" tab="土地资源导入">
        <a-card class="import-card">
          <a-form layout="vertical">
            <a-form-item
              label="选择导入文件"
              name="landFile"
              :rules="[{ required: true, message: '请选择要导入的文件' }]"
            >
              <a-upload
                v-model:file-list="landFileList"
                :before-upload="beforeUpload"
                action="#"
                :multiple="false"
                :show-upload-list="true"
              >
                <a-button>
                  <template #icon><UploadOutlined /></template>
                  选择文件
                </a-button>
              </a-upload>
            </a-form-item>
            <a-form-item>
              <a-button type="primary" @click="handleLandImport" :disabled="landFileList.length === 0">
                导入数据
              </a-button>
              <a-button style="margin-left: 10px" @click="downloadLandTemplate">
                下载模板
              </a-button>
            </a-form-item>
          </a-form>

          <div class="import-instructions">
            <h3>导入说明</h3>
            <ol>
              <li>请下载导入模板，并按照模板格式填写数据</li>
              <li>支持导入 Excel 文件（.xlsx, .xls）</li>
              <li>文件大小不超过10MB</li>
              <li>单次导入记录不超过1000条</li>
            </ol>
          </div>
        </a-card>
      </a-tab-pane>

      <a-tab-pane key="property" tab="房产导入">
        <a-card class="import-card">
          <a-form layout="vertical">
            <a-form-item
              label="选择导入文件"
              name="propertyFile"
              :rules="[{ required: true, message: '请选择要导入的文件' }]"
            >
              <a-upload
                v-model:file-list="propertyFileList"
                :before-upload="beforeUpload"
                action="#"
                :multiple="false"
                :show-upload-list="true"
              >
                <a-button>
                  <template #icon><UploadOutlined /></template>
                  选择文件
                </a-button>
              </a-upload>
            </a-form-item>
            <a-form-item>
              <a-button type="primary" @click="handlePropertyImport" :disabled="propertyFileList.length === 0">
                导入数据
              </a-button>
              <a-button style="margin-left: 10px" @click="downloadPropertyTemplate">
                下载模板
              </a-button>
            </a-form-item>
          </a-form>

          <div class="import-instructions">
            <h3>导入说明</h3>
            <ol>
              <li>请下载导入模板，并按照模板格式填写数据</li>
              <li>支持导入 Excel 文件（.xlsx, .xls）</li>
              <li>文件大小不超过10MB</li>
              <li>单次导入记录不超过1000条</li>
            </ol>
          </div>
        </a-card>
      </a-tab-pane>

      <a-tab-pane key="merge" tab="合并导入">
        <a-card class="import-card">
          <a-form layout="vertical">
            <a-form-item
              label="选择导入文件"
              name="mergeFile"
              :rules="[{ required: true, message: '请选择要导入的文件' }]"
            >
              <a-upload
                v-model:file-list="mergeFileList"
                :before-upload="beforeUpload"
                action="#"
                :multiple="false"
                :show-upload-list="true"
              >
                <a-button>
                  <template #icon><UploadOutlined /></template>
                  选择文件
                </a-button>
              </a-upload>
            </a-form-item>
            <a-form-item>
              <a-button type="primary" @click="handleMergeImport" :disabled="mergeFileList.length === 0">
                导入数据
              </a-button>
              <a-button style="margin-left: 10px" @click="downloadMergeTemplate">
                下载模板
              </a-button>
            </a-form-item>
          </a-form>

          <div class="import-instructions">
            <h3>导入说明</h3>
            <ol>
              <li>请下载导入模板，并按照模板格式填写数据</li>
              <li>支持导入 Excel 文件（.xlsx, .xls）</li>
              <li>文件大小不超过10MB</li>
              <li>单次导入记录不超过1000条</li>
            </ol>
          </div>
        </a-card>
      </a-tab-pane>
    </a-tabs>
  </div>
</template>

<script lang="ts" setup>
import { ref } from 'vue'
import { message } from 'ant-design-vue'
import { UploadOutlined } from '@ant-design/icons-vue'

// 文件列表
const landFileList = ref<any[]>([])
const propertyFileList = ref<any[]>([])
const mergeFileList = ref<any[]>([])

// 上传前校验
const beforeUpload = (file: File) => {
  const isExcel = file.type === 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet' || 
                 file.type === 'application/vnd.ms-excel'
  if (!isExcel) {
    message.error('只能上传Excel文件！')
  }
  
  const isLt10M = file.size / 1024 / 1024 < 10
  if (!isLt10M) {
    message.error('文件大小不能超过10MB！')
  }
  
  return false
}

// 导入土地资源
const handleLandImport = () => {
  if (landFileList.value.length === 0) {
    message.warning('请先选择要导入的文件')
    return
  }
  
  // TODO: 实现导入逻辑
  message.loading('正在导入数据...')
  setTimeout(() => {
    message.success('导入成功！')
    landFileList.value = []
  }, 2000)
}

// 导入房产
const handlePropertyImport = () => {
  if (propertyFileList.value.length === 0) {
    message.warning('请先选择要导入的文件')
    return
  }
  
  // TODO: 实现导入逻辑
  message.loading('正在导入数据...')
  setTimeout(() => {
    message.success('导入成功！')
    propertyFileList.value = []
  }, 2000)
}

// 合并导入
const handleMergeImport = () => {
  if (mergeFileList.value.length === 0) {
    message.warning('请先选择要导入的文件')
    return
  }
  
  // TODO: 实现合并导入逻辑
  message.loading('正在合并导入数据...')
  setTimeout(() => {
    message.success('合并导入成功！')
    mergeFileList.value = []
  }, 2000)
}

// 下载土地资源导入模板
const downloadLandTemplate = () => {
  // TODO: 实现模板下载逻辑
  message.success('模板下载成功！')
}

// 下载房产导入模板
const downloadPropertyTemplate = () => {
  // TODO: 实现模板下载逻辑
  message.success('模板下载成功！')
}

// 下载合并导入模板
const downloadMergeTemplate = () => {
  // TODO: 实现模板下载逻辑
  message.success('合并导入模板下载成功！')
}
</script>

<style lang="scss" scoped>
.asset-import {
  .page-header {
    margin-bottom: 24px;
    
    h2 {
      margin-bottom: 16px;
      font-size: 24px;
    }
  }
  
  .import-tabs {
    margin-bottom: 24px;
  }
  
  .import-card {
    border-radius: 8px;
    box-shadow: 0 1px 2px rgba(0, 0, 0, 0.05);
    margin-bottom: 24px;
  }
  
  .import-instructions {
    margin-top: 24px;
    padding-top: 16px;
    border-top: 1px dashed #e0e0e0;
    
    h3 {
      margin-bottom: 12px;
      font-size: 16px;
    }
    
    ol {
      padding-left: 24px;
      
      li {
        margin-bottom: 8px;
        color: #666;
      }
    }
  }
}
</style> 