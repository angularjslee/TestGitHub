<template>
  <router-view></router-view>
</template>

<script lang="ts" setup>
// Root component
</script>

<style>
#app {
  height: 100vh;
}
</style> 