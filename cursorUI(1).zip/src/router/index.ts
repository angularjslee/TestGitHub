import { createRouter, createWebHistory } from 'vue-router'
import MainLayout from '../layouts/MainLayout.vue'
import Dashboard from '../pages/Dashboard.vue'
import UserList from '../pages/user/UserList.vue'
import RoleList from '../pages/system/RoleList.vue'
import PermissionList from '../pages/system/PermissionList.vue'
import PropertyList from '../pages/property/PropertyList.vue'
import ReportList from '../pages/reports/ReportList.vue'
import DepartmentList from '../pages/system/DepartmentList.vue'
import LandList from '../pages/land/LandList.vue'
import RecordStructure from '../pages/system/RecordStructure.vue'
import AssetImport from '../pages/assets/AssetImport.vue'

const routes = [
  {
    path: '/',
    component: MainLayout,
    children: [
      {
        path: '',
        name: 'dashboard',
        component: Dashboard
      },
      {
        path: 'land',
        name: 'land',
        component: LandList
      },
      {
        path: 'users',
        name: 'users',
        component: UserList
      },
      {
        path: 'roles',
        name: 'roles',
        component: RoleList
      },
      {
        path: 'departments',
        name: 'departments',
        component: DepartmentList
      },
      {
        path: 'permissions',
        name: 'permissions',
        component: PermissionList
      },
      {
        path: 'properties',
        name: 'properties',
        component: PropertyList
      },
      {
        path: 'reports',
        name: 'reports',
        component: ReportList
      },
      {
        path: 'record-structure',
        name: 'record-structure',
        component: RecordStructure
      },
      {
        path: 'asset-import',
        name: 'asset-import',
        component: AssetImport
      }
    ]
  }
]

export const router = createRouter({
  history: createWebHistory(),
  routes
})

export default router 