const colors = ['#5470C6', '#91CC75', '#EE6666', '#73C0DE', '#FFA500'];
option = {
  color: colors,
  textStyle: {
    fontSize: 20  // 全局字体大小增大
  },
  tooltip: {
    trigger: 'axis',
    axisPointer: {
      type: 'cross'
    },
    textStyle: {
      fontSize: 20  // 提示框字体大小增大
    }
  },
  grid: {
    right: '20%',
    bottom: '18%'  // 增加底部空间
  },
  toolbox: {
    feature: {
      dataView: { show: true, readOnly: false },
      restore: { show: true },
      saveAsImage: { show: true }
    },
    iconStyle: {
      borderWidth: 3
    },
    emphasis: {
      iconStyle: {
        borderWidth: 4
      }
    }
  },
  legend: {
    data: ['35岁及以下', '36-45岁', '46-54岁', '55岁及以上', '平均年龄'],
    textStyle: {
      fontSize: 20  // 图例字体大小增大
    },
    itemWidth: 30,
    itemHeight: 18
  },
  xAxis: [
    {
      type: 'category',
      axisTick: {
        alignWithLabel: true
      },
      data: ['全民用工', '集体用工', '合同制用工', '劳务派遣用工'],
      axisLabel: {
        formatter: function (value) {
          const totalMap = {
            '全民用工': 606,
            '集体用工': 440,
            '合同制用工': 154,
            '劳务派遣用工': 436
          };
          return value + '\n人数: ' + totalMap[value];
        },
        interval: 0,
        rotate: 0,
        margin: 25,
        fontSize: 20,  // X轴标签字体大小增大
        lineHeight: 30
      },
      nameTextStyle: {
        fontSize: 20  // X轴名称字体大小增大
      }
    }
  ],
  yAxis: [
    {
      type: 'value',
      name: '人数',
      position: 'left',
      alignTicks: true,
      axisLine: {
        show: true,
        lineStyle: {
          color: colors[0],
          width: 3
        }
      },
      axisLabel: {
        formatter: '{value} 人',
        fontSize: 20  // Y轴标签字体大小增大
      },
      nameTextStyle: {
        fontSize: 22,  // Y轴名称字体大小增大
        padding: [0, 0, 0, 15]  // 调整名称位置
      }
    },
    {
      type: 'value',
      name: '平均年龄',
      position: 'right',
      alignTicks: true,
      axisLine: {
        show: true,
        lineStyle: {
          color: colors[4],
          width: 3
        }
      },
      axisLabel: {
        formatter: '{value} 岁',
        fontSize: 20  // Y轴标签字体大小增大
      },
      nameTextStyle: {
        fontSize: 22,  // Y轴名称字体大小增大
        padding: [0, 15, 0, 0]  // 调整名称位置
      }
    }
  ],
  series: [
    {
      name: '35岁及以下',
      type: 'bar',
      data: [35, 0, 6, 140],
      barWidth: '18%',  // 调整柱子宽度
      emphasis: {
        itemStyle: {
          shadowBlur: 15,
          shadowOffsetX: 0,
          shadowColor: 'rgba(0, 0, 0, 0.5)'
        }
      }
    },
    {
      name: '36-45岁',
      type: 'bar',
      data: [172, 6, 77, 202],
      barWidth: '18%',  // 调整柱子宽度
      emphasis: {
        itemStyle: {
          shadowBlur: 15,
          shadowOffsetX: 0,
          shadowColor: 'rgba(0, 0, 0, 0.5)'
        }
      }
    },
    {
      name: '46-54岁',
      type: 'bar',
      data: [240, 201, 58, 68],
      barWidth: '18%',  // 调整柱子宽度
      emphasis: {
        itemStyle: {
          shadowBlur: 15,
          shadowOffsetX: 0,
          shadowColor: 'rgba(0, 0, 0, 0.5)'
        }
      }
    },
    {
      name: '55岁及以上',
      type: 'bar',
      data: [159, 233, 13, 26],
      barWidth: '18%',  // 调整柱子宽度
      emphasis: {
        itemStyle: {
          shadowBlur: 15,
          shadowOffsetX: 0,
          shadowColor: 'rgba(0, 0, 0, 0.5)'
        }
      }
    },
    {
      name: '平均年龄',
      type: 'line',
      yAxisIndex: 1,
      symbol: 'circle',
      symbolSize: 12,  // 增大标记点大小
      lineStyle: {
        width: 5  // 增大线宽
      },
      data: [48.62, 54.32, 44.76, 39.48],
      label: {
        show: true,
        position: 'top',
        fontSize: 20,  // 标签字体大小增大
        formatter: '{c} 岁'
      }
    }
  ]
}; 