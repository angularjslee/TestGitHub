const colors = ['#5470C6', '#91CC75', '#EE6666', '#73C0DE', '#FFA500'];
option = {
  color: colors,
  textStyle: {
    fontSize: 24  // 全局字体大小增大
  },
  tooltip: {
    trigger: 'axis',
    axisPointer: {
      type: 'cross'
    },
    textStyle: {
      fontSize: 24  // 提示框字体大小增大
    }
  },
  grid: {
    right: '20%',
    bottom: '18%'  // 增加底部空间
  },
  toolbox: {
    feature: {
      dataView: { show: true, readOnly: false },
      restore: { show: true },
      saveAsImage: { show: true }
    },
    iconStyle: {
      borderWidth: 3
    },
    emphasis: {
      iconStyle: {
        borderWidth: 4
      }
    }
  },
  legend: {
    data: ['人数', '平均年龄'],
    textStyle: {
      fontSize: 24  // 图例字体大小增大
    },
    itemWidth: 35,
    itemHeight: 20
  },
  xAxis: [
    {
      type: 'category',
      axisTick: {
        alignWithLabel: true
      },
      data: ['全民用工', '集体用工', '合同制用工', '劳务派遣用工'],
      axisLabel: {
        interval: 0,
        rotate: 0,
        margin: 30,
        fontSize: 24,  // X轴标签字体大小增大
        lineHeight: 35
      },
      nameTextStyle: {
        fontSize: 24  // X轴名称字体大小增大
      }
    }
  ],
  yAxis: [
    {
      type: 'value',
      name: '人数',
      position: 'left',
      alignTicks: true,
      axisLine: {
        show: true,
        lineStyle: {
          color: colors[0],
          width: 3
        }
      },
      axisLabel: {
        formatter: '{value} 人',
        fontSize: 24  // Y轴标签字体大小增大
      },
      nameTextStyle: {
        fontSize: 26,  // Y轴名称字体大小增大
        padding: [0, 0, 0, 20]  // 调整名称位置
      }
    },
    {
      type: 'value',
      name: '平均年龄',
      position: 'right',
      alignTicks: true,
      axisLine: {
        show: true,
        lineStyle: {
          color: colors[4],
          width: 3
        }
      },
      axisLabel: {
        formatter: '{value} 岁',
        fontSize: 24  // Y轴标签字体大小增大
      },
      nameTextStyle: {
        fontSize: 26,  // Y轴名称字体大小增大
        padding: [0, 20, 0, 0]  // 调整名称位置
      }
    }
  ],
  series: [
    {
      name: '人数',
      type: 'bar',
      data: [606, 440, 154, 436],
      barWidth: '40%',  // 调整柱子宽度
      itemStyle: {
        color: colors[0]
      },
      label: {
        show: true,
        position: 'top',
        fontSize: 24,
        formatter: '{c} 人'
      },
      emphasis: {
        itemStyle: {
          shadowBlur: 15,
          shadowOffsetX: 0,
          shadowColor: 'rgba(0, 0, 0, 0.5)'
        }
      }
    },
    {
      name: '平均年龄',
      type: 'line',
      yAxisIndex: 1,
      symbol: 'circle',
      symbolSize: 14,  // 增大标记点大小
      lineStyle: {
        width: 5  // 增大线宽
      },
      itemStyle: {
        color: colors[4]
      },
      data: [48.62, 54.32, 44.76, 39.48],
      label: {
        show: true,
        position: 'top',
        fontSize: 24,  // 标签字体大小增大
        formatter: '{c} 岁'
      }
    }
  ]
}; 